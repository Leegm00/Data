package com.three.cucumber.serviceImpl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.three.cucumber.service.BlockService;
import com.three.cucumber.service.dao.BlockDAO;
import com.three.cucumber.vo.BlockVO;

@Service("blockService")
public class BlockServiceImpl implements BlockService{
	@Autowired
	private BlockDAO blockDAO;

	@Override
	public void inBlock(BlockVO bvo) {
		int cnt = blockDAO.blockCh(bvo);
		if(cnt==0)
			blockDAO.inBlock(bvo);
		
	}

	@Override
	public int blockCh(int blocker, int blocked) {
		BlockVO bvo = new BlockVO(0,blocker,blocked,null);
		return blockDAO.blockCh(bvo);
	}

	@Override
	public ArrayList<BlockVO> getAllBlock(int memId) {
		// TODO Auto-generated method stub
		return blockDAO.getAllBlock(memId);
	}

	@Override
	public void delBlock(Integer blockId) {
		blockDAO.delBlock(blockId);
		
	}

}
