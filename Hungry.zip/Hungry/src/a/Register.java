package a;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import repository.Member;
import repository.MemberAlreadyException;
import repository.PasswordNotMatchedException;
import service.Service;

public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField txtRegID;
	private JTextField txtRegPw;
	private JTextField txtRegPw2;
	private JTextField txtRegEmail;
	private JTextField txtRegTel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
//		System.setProperty("file.encoding", "UTF-8");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setTitle("회원 가입");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 439, 406);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegId = new JLabel("아이디");
		lblRegId.setBounds(50, 10, 91, 34);
		lblRegId.setFont(new Font("굴림", Font.PLAIN, 15));
		contentPane.add(lblRegId);
		
		JLabel lblRegPw = new JLabel("비밀번호");
		lblRegPw.setBounds(50, 54, 91, 34);
		lblRegPw.setFont(new Font("굴림", Font.PLAIN, 15));
		contentPane.add(lblRegPw);
		
		JLabel lblRegId_2 = new JLabel("비밀번호 확인");
		lblRegId_2.setBounds(50, 98, 111, 34);
		lblRegId_2.setFont(new Font("굴림", Font.PLAIN, 15));
		contentPane.add(lblRegId_2);
		
		JLabel lblRegAge = new JLabel("나이");
		lblRegAge.setBounds(50, 258, 91, 26);
		lblRegAge.setFont(new Font("굴림", Font.PLAIN, 15));
		contentPane.add(lblRegAge);
		
		JLabel lblRegGen = new JLabel("성별");
		lblRegGen.setBounds(50, 222, 91, 26);
		lblRegGen.setFont(new Font("굴림", Font.PLAIN, 15));
		contentPane.add(lblRegGen);
		
		JLabel lblRegEmail = new JLabel("이메일");
		lblRegEmail.setBounds(50, 142, 91, 34);
		lblRegEmail.setFont(new Font("굴림", Font.PLAIN, 15));
		contentPane.add(lblRegEmail);
		
		JLabel lblRegTel= new JLabel("전화번호");
		lblRegTel.setBounds(50, 186, 91, 34);
		lblRegTel.setFont(new Font("굴림", Font.PLAIN, 15));
		contentPane.add(lblRegTel);
		
		txtRegID = new JTextField();
		txtRegID.setBounds(177, 18, 201, 26);
		contentPane.add(txtRegID);
		txtRegID.setColumns(10);
		
		txtRegPw = new JTextField();
		txtRegPw.setColumns(10);
		txtRegPw.setBounds(177, 62, 201, 26);
		contentPane.add(txtRegPw);
		
		txtRegPw2 = new JTextField();
		txtRegPw2.setColumns(10);
		txtRegPw2.setBounds(177, 104, 201, 26);
		contentPane.add(txtRegPw2);
		
		JComboBox comboAge = new JComboBox();
		comboAge.setModel(new DefaultComboBoxModel(new String[] {"10대", "20대", "30대", "40대", "50대 이상"}));
		comboAge.setToolTipText("");
		comboAge.setBounds(177, 255, 201, 34);
		contentPane.add(comboAge);
		
		JRadioButton raM = new JRadioButton("남성");
		raM.setBounds(177, 225, 91, 23);
		contentPane.add(raM);
		
		JRadioButton raF = new JRadioButton("여성");
		raF.setBounds(272, 229, 91, 23);
		contentPane.add(raF);
		
		ButtonGroup raGroup = new ButtonGroup();
		raGroup.add(raM);

		raGroup.add(raF);

		getContentPane().add(raM);

		getContentPane().add(raF);
		
		txtRegEmail = new JTextField();
		txtRegEmail.setColumns(10);
		txtRegEmail.setBounds(177, 148, 201, 26);
		contentPane.add(txtRegEmail);
		
		txtRegTel = new JTextField();
		txtRegTel.setColumns(10);
		txtRegTel.setBounds(177, 192, 201, 26);
		contentPane.add(txtRegTel);
		
		
		JButton btnRegister = new JButton("가입하기");
		btnRegister.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Service svc = new Service();
				String id = txtRegID.getText();
				String pw = txtRegPw.getText();
				String pw2 = txtRegPw2.getText();
		        String age = (String) comboAge.getSelectedItem();
		        String email =txtRegEmail.getText();
		        String tel =txtRegTel.getText();
		    
				String gender;
				if (raM.isSelected()) {
				    gender = "M";
				} else if (raF.isSelected()) {
				    gender = "F";
				} else {
				    gender = null;
				}
				
				 try {
			            svc.register(id, pw, pw2, gender, email,tel,age);
			            System.out.printf(id, pw, pw2, age, gender,email,tel);
			            JOptionPane.showMessageDialog(null, "회원가입이 완료되었습니다.");
			            dispose(); // 현재 창 닫기
			        } catch(NullPointerException ne) {
			        	ne.printStackTrace();
			        	JOptionPane.showMessageDialog(null, "모든 항목은 필수 항목입니다.");
			        }catch (MemberAlreadyException e1) {
			        	e1.printStackTrace();
			            JOptionPane.showMessageDialog(null, "이미 등록된 아이디입니다. 다른 아이디를 입력해주세요.");
			        } catch (PasswordNotMatchedException e2) {
			        	e2.printStackTrace();
			            JOptionPane.showMessageDialog(null, "비밀번호가 일치하지 않습니다. 다시 입력해주세요.");
			        } catch (Exception e3) {
			        	e3.printStackTrace();
			            JOptionPane.showMessageDialog(null, "회원가입에 실패했습니다. 다시 시도해주세요.");
			        }
			}
		});
		btnRegister.setBounds(110, 303, 158, 56);
		contentPane.add(btnRegister);
	}
}
