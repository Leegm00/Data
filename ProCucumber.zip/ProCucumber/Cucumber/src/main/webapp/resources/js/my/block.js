function delBlock(e) {
	if(window.confirm('회원 차단을 취소하시겠습니까?')) {
		location.href='delBlock.do?blockId='+e;
	}
}