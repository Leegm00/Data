package com.three.cucumber.vo;

public class RepContentVO {
	private int repId;
	private String repContent;
	private int cnt;
	
	public RepContentVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RepContentVO(int repId, String repContent, int cnt) {
		super();
		this.repId = repId;
		this.repContent = repContent;
		this.cnt = cnt;
	}
	
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public int getRepId() {
		return repId;
	}
	public void setRepId(int repId) {
		this.repId = repId;
	}
	public String getRepContent() {
		return repContent;
	}
	public void setRepContent(String repContent) {
		this.repContent = repContent;
	}
	
}
