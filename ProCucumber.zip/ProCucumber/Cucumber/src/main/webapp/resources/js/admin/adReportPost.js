function delPost(e) {
	if(window.confirm('게시물을 삭제하시겠습니까?'))
		location.href="AdDelPost.do?postId="+e;
	else return false;
}

function delRepPost(e){
	if(window.confirm('게시물신고를 삭제하시겠습니까?'))
		location.href="delrepPost.do?postId="+e;
	else return false;
}

function yellow(e){
	if(window.confirm('게시물 작성자를 경고하시겠습니까?')) {
			$.ajax({
			type : 'post',
			url : "yellowPost.do",
			data : {
				postId : e
			},
			success : function (data) {
				alert("게시물 작성자에게 경고가 완료되었습니다");
			}					
		}); // end ajax
	}
	else return false;
}