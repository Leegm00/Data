package com.three.cucumber.vo;

public class GraphVO {
	private String type;
	private String pipath;
	private String upload;
	
	
	public GraphVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GraphVO(String type, String pipath, String upload) {
		super();
		this.type = type;
		this.pipath = pipath;
		this.upload = upload;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPipath() {
		return pipath;
	}
	public void setPipath(String pipath) {
		this.pipath = pipath;
	}
	public String getUpload() {
		return upload;
	}
	public void setUpload(String upload) {
		this.upload = upload;
	}
	
	
}
