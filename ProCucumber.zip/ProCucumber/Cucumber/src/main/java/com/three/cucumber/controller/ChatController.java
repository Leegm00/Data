package com.three.cucumber.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.three.cucumber.service.AlarmService;
import com.three.cucumber.service.BlockService;
import com.three.cucumber.service.ChatService;
import com.three.cucumber.service.MemberService;
import com.three.cucumber.service.PostService;
import com.three.cucumber.service.RepContentService;
import com.three.cucumber.service.ReportService;
import com.three.cucumber.vo.AlarmVO;
import com.three.cucumber.vo.BlockVO;
import com.three.cucumber.vo.BuyVO;
import com.three.cucumber.vo.ChatLogVO;
import com.three.cucumber.vo.ChatReportVO;
import com.three.cucumber.vo.ChatVO;
import com.three.cucumber.vo.MeetVO;
import com.three.cucumber.vo.MemberVO;
import com.three.cucumber.vo.MsgVO;
import com.three.cucumber.vo.PostVO;
import com.three.cucumber.vo.RepContentVO;

@Controller
public class ChatController {
	
	@Resource(name="chatService")
	private ChatService chatSer;
	
	@Resource(name="memberService")
	private MemberService memSer;
	
	@Resource(name="PostService")
	private PostService postSer;
	
	@Resource(name="blockService")
	private BlockService bSer;
	
	@Resource(name="alarmService")
	private AlarmService aSer;
	
	@Resource(name="repContentService")
	private RepContentService rcSer;
	
	@Resource(name="reportService")
	private ReportService repSer;
	
	@RequestMapping(value="insertChat.do") 
	public String insertChat(HttpServletRequest request, Integer postId) {
		int chatId = chatSer.insertchat(postId, memSer.getSession(request));
		return "redirect:findChat.do?chatId="+chatId;
	}
	
	 @RequestMapping(value="chatlist.do") 
	 private String getAllChat(HttpServletRequest request, Model model) {
			HttpSession session = request.getSession(false);
			if(session == null || session.getAttribute("sesId")==null) {
				return "redirect:main.do?alarm=badmem";
			}
		 int memId = memSer.getSession(request);
		 ArrayList<ChatVO> carray = chatSer.getAllChat(memId);
		 HashMap<Integer, Integer> cntmap = chatSer.getAllMsgCount(memId);
		 HashMap<Integer, String> pmap = chatSer.getAllPost(memId);
		 HashMap<Integer, MemberVO> nickmap = chatSer.getAllNick(memId);
		 model.addAttribute("nickmap", nickmap);
		 model.addAttribute("pmap", pmap);
		 model.addAttribute("carray", carray);
		 model.addAttribute("cntmap", cntmap);
		 return "/chat/chat"; 
	 }
	 @RequestMapping(value="findChat.do") 
	 private String findChat(HttpServletRequest request, Integer chatId, Model model) {
			HttpSession session = request.getSession(false);
			if(session == null || session.getAttribute("sesId")==null) {
				return "redirect:main.do?alarm=badmem";
			}
		 int memId = memSer.getSession(request);
		 chatSer.updateMsgRead(chatId,memId);
		 ArrayList<MsgVO> marray = chatSer.getAllMsg(chatId, memId); 
		 PostVO pvo = chatSer.findPost(chatId);
		 MemberVO nick = chatSer.findNick(chatId, memId);
		 MeetVO mvo = chatSer.findMeet(chatId);
		 ArrayList<RepContentVO> reparray = rcSer.allRepCont();
		 
		 model.addAttribute("reparray", reparray);
		 model.addAttribute("chatId", chatId);
		 model.addAttribute("nick", nick);
		 model.addAttribute("marray", marray);
		 model.addAttribute("pvo", pvo);
		 model.addAttribute("mvo", mvo);
		 return "/chat/oneChat";
	 }
	 
	@RequestMapping(value="chatlog.do", method=RequestMethod.POST)
	@ResponseBody
	public int chatin(HttpServletRequest request, ChatLogVO lvo) {
		lvo.setMemId(memSer.getSession(request));
		int re = chatSer.insertchatlog(lvo);
		return re;
	}
	
	@RequestMapping(value="chatlogout.do", method=RequestMethod.POST)
	@ResponseBody
	public int chatout(HttpServletRequest request, ChatLogVO lvo) {
		lvo.setMemId(memSer.getSession(request));
		int re = chatSer.deletechatlog(lvo);
		return re;
	}
	
	 @RequestMapping(value="chatloguser.do", method=RequestMethod.POST)
	 @ResponseBody
	 public int chatloguser(HttpServletRequest request, ChatLogVO lvo) {
		lvo.setMemId(memSer.getSession(request));
		 int cnt = chatSer.findChatLog(lvo);
		 int read = 0;
		 if(cnt == 0) read = 1;
		 return read;
	 }
	 
	 
	 @RequestMapping(value="insertMsg.do", method=RequestMethod.POST)
	 @ResponseBody
	 public int insertMsg(HttpServletRequest request, MsgVO mvo) {
		 mvo.setMsgWriter(memSer.getSession(request));
		 int blocker = chatSer.findNick(mvo.getChatId(), mvo.getMsgWriter()).getMemId();
		 int cnt = bSer.blockCh(blocker, mvo.getMsgWriter());
		 if(cnt == 0 && mvo.getMsgRead()==1) {
			 AlarmVO avo = new AlarmVO(0, blocker, mvo.getChatId(), "["+memSer.findNick(mvo.getMsgWriter())+"] ���� ä���� ���½��ϴ�", "chat");
			 int chatalcnt = aSer.getChatAlCnt(avo);
			 if(chatalcnt != 0) {
				 aSer.delChatAl(avo);
			 }
			aSer.insertAlQna(avo);
		 }
		 int re = chatSer.insertMsg(mvo);
		 return re;
	 }
	 
	 @RequestMapping(value="deleteChat.do")
	 public String deleteChat(HttpServletRequest request, Integer chatId,Model model) {
			HttpSession session = request.getSession(false);
			if(session == null || session.getAttribute("sesId")==null) {
				return "redirect:main.do?alarm=badmem";
			}
		 chatSer.UpChatStatus(chatId, memSer.getSession(request));
		 return "redirect:chatlist.do";
	 }
	 
	 @RequestMapping(value="upPostStatus.do", method=RequestMethod.POST)
	 @ResponseBody
	 public void upPostStatus(HttpServletRequest request, Integer postId, String status, Integer chatId) throws SQLException {
		 
		 
		 chatSer.upPostStatus(postId, status);
		 
		 if(status.equals("�ŷ��Ϸ�")) {
			 PostVO pvo = postSer.getPostVO(postId);
			 int memId = memSer.getSession(request);
			 ChatVO cvo = chatSer.findChat(chatId);
			 int youId = cvo.getChatFrom();
			 int buyId = chatSer.getnextBuyId();
			 BuyVO bvo = new BuyVO(buyId,youId,memId,pvo.getPostTitle(),pvo.getPostPrice(),pvo.getMainPipath(), 0);
			 String postdir = request.getSession().getServletContext().getRealPath("/resources/sang_img");
			 String buydir= request.getSession().getServletContext().getRealPath("/resources/buy_img");
			 chatSer.inBuy(postdir, buydir, bvo);
			 // �˶�
			 AlarmVO avo = new AlarmVO(0, bvo.getSeller(), postId, "["+memSer.findNick(bvo.getBuyer())+"] �԰��� �ŷ��� �Ϸ�Ǿ����ϴ�", "buy");
			 aSer.insertAlQna(avo);
			 int cnt = bSer.blockCh(bvo.getBuyer(), bvo.getSeller());
			 if(cnt == 0) {
				 AlarmVO aavo = new AlarmVO(0, bvo.getBuyer(), buyId, "["+memSer.findNick(bvo.getSeller())+"] �԰��� �ŷ��� �Ϸ�Ǿ����ϴ�", "buy");
				 aSer.insertAlQna(aavo);
			 }
		 }
		 
		 
	 }
	 
	 @RequestMapping(value="insertMeet.do", method=RequestMethod.POST) 
	 @ResponseBody
	 private void insertMeet(MeetVO mvo, Model model) {
		 chatSer.insertMeet(mvo);
		 // �˶�
		 AlarmVO avo = new AlarmVO(0, mvo.getMeetFrom(), mvo.getChatId(), "["+memSer.findNick(mvo.getMeetTo())+"] �԰� " + mvo.getMeetDate() + ", " + mvo.getMeetTime() + " �� �ŷ������ �����Ǿ����ϴ�", "meet");
		 int nt = aSer.getMeetAlCnt(avo);
		 if(nt == 0)
			 aSer.insertAlQna(avo);
		 else
			 aSer.upMeetAl(avo);
		 aSer.insertAlQna(avo);
		 int cnt = bSer.blockCh(mvo.getMeetTo(), mvo.getMeetFrom());
		 if(cnt == 0) {
			 AlarmVO aavo = new AlarmVO(0, mvo.getMeetTo(), mvo.getChatId(), "["+memSer.findNick(mvo.getMeetFrom())+"] �԰� " + mvo.getMeetDate() + ", " + mvo.getMeetTime() + " �� �ŷ������ �����Ǿ����ϴ�", "meet");
			 int ccnt = aSer.getMeetAlCnt(aavo);
			 if(ccnt == 0)
				 aSer.insertAlQna(aavo);
			 else
				 aSer.upMeetAl(aavo);
		 }
	 }
	 
	 @RequestMapping(value="delMeet.do", method=RequestMethod.POST) 
	 @ResponseBody
	 private void delMeet(int meetId, Model model) {
		 chatSer.delMeet(meetId);
	 }
	 
	 @RequestMapping(value="backDelChat.do", method=RequestMethod.POST)
	 @ResponseBody
	 public void backDelChat(Integer chatId) {
		 chatSer.backDelChat(chatId);
	 }

		@RequestMapping(value="chatReport.do", method= RequestMethod.POST)
		public String insertChatRep(ChatReportVO crvo,Model model, Integer chatId,
					@RequestParam("upload")MultipartFile[] upload, HttpServletRequest request) throws SQLException, IllegalStateException, IOException {
			HttpSession session = request.getSession(false);
			if(session == null || session.getAttribute("sesId")==null) {
				return "redirect:main.do?alarm=badmem";
			}
			crvo.setChatReporter(memSer.getSession(request));
			
			String saveDir = request.getSession().getServletContext().getRealPath("/resources/chat_report");
		    File dir = new File(saveDir);
		    if(!dir.exists()) {
		    	dir.mkdirs();
		    }
		    for(MultipartFile f : upload) {
		    	if(!f.isEmpty()) {
		    		String orifileName = f.getOriginalFilename();
		    		String ext = orifileName.substring(orifileName.lastIndexOf("."));
		    		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-HHmmssSSS");
		    		int rand = (int)(Math.random()*1000);
		    		String reName = sdf.format(System.currentTimeMillis()) + "_" + rand + ext;
		    		crvo.setChatReportPipath(reName);
		    		try { f.transferTo(new File(saveDir + "/" + reName));
		            }catch (IOException e) { e.printStackTrace(); }
		    	}            
		    }
		    
		    repSer.insertChatRep(crvo);
		    return "redirect:findChat.do?chatId="+chatId;			
		}

}
