package com.three.cucumber.serviceImpl;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.three.cucumber.service.MemberService;
import com.three.cucumber.service.PostService;
import com.three.cucumber.service.ReportPostService;
import com.three.cucumber.service.dao.ReportPostDAO;
import com.three.cucumber.vo.RepContentVO;
import com.three.cucumber.vo.ReportPostVO;

@Service("reportPostService")
public class ReportPostServiceImpl implements ReportPostService {
	
	@Autowired
	private ReportPostDAO rpdao;
	
	@Resource(name="memberService")
	private MemberService mSer;
	
	@Resource(name="PostService")
	private PostService pSer;

	@Override
	public void reportInsertatPost(ReportPostVO rpvo) {
		int cnt = rpdao.repPostCh(rpvo);
		if(cnt == 0)
			rpdao.reportInsertatPost(rpvo);
	}

	@Override
	public ArrayList<ReportPostVO> allReportPost(int postId) {
		// TODO Auto-generated method stub
		return rpdao.allReportPost(postId);
	}

	// ��ü �Ű��� �Խù� ����Ʈ�� ��������, �Ű� �Խñ��� ����� �Ű��� ����� �г����� ���������� ��
	@Override
	public ArrayList<ReportPostVO> getEveryReportPost() {
		// TODO Auto-generated method stub
		
		ArrayList<ReportPostVO> rparray = rpdao.getEveryReportPost();
		
		return rparray;
	}

	@Override
	public void AdDelPost(int postId) throws SQLException {
		pSer.deletePost(postId);
		rpdao.delRepPostByPost(postId);
	}

	@Override
	public void delRepPost(int postId) {
		rpdao.delRepPost(postId);
		
	}

	@Override
	public ArrayList<RepContentVO> getRepCnt(int postId) {
		// TODO Auto-generated method stub
		return rpdao.getRepCnt(postId);
	}

	

}
