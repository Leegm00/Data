package com.three.cucumber.vo;

public class AlarmVO {
	private int alarmId;
	private int alarmMem;
	private int alarmPost;
	private String alarmContent;
	private String alarmType;
	
	
	public AlarmVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AlarmVO(int alarmId, int alarmMem, int alarmPost, String alarmContent, String alarmType) {
		super();
		this.alarmId = alarmId;
		this.alarmMem = alarmMem;
		this.alarmPost = alarmPost;
		this.alarmContent = alarmContent;
		this.alarmType = alarmType;
	}
	public int getAlarmId() {
		return alarmId;
	}
	public void setAlarmId(int alarmId) {
		this.alarmId = alarmId;
	}
	public int getAlarmMem() {
		return alarmMem;
	}
	public void setAlarmMem(int alarmMem) {
		this.alarmMem = alarmMem;
	}
	public int getAlarmPost() {
		return alarmPost;
	}
	public void setAlarmPost(int alarmPost) {
		this.alarmPost = alarmPost;
	}
	public String getAlarmContent() {
		return alarmContent;
	}
	public void setAlarmContent(String alarmContent) {
		this.alarmContent = alarmContent;
	}
	public String getAlarmType() {
		return alarmType;
	}
	public void setAlarmType(String alarmType) {
		this.alarmType = alarmType;
	}
	
	
}
