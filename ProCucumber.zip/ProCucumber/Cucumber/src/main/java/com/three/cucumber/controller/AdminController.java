package com.three.cucumber.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.three.cucumber.service.MemberService;
import com.three.cucumber.service.PostService;
import com.three.cucumber.service.ProfileService;
import com.three.cucumber.service.QnaService;
import com.three.cucumber.service.RepContentService;
import com.three.cucumber.service.ReportPostService;
import com.three.cucumber.service.ReportQnaService;
import com.three.cucumber.service.ReportService;
import com.three.cucumber.vo.CateVO;
import com.three.cucumber.vo.ChatReportVO;
import com.three.cucumber.vo.ChatVO;
import com.three.cucumber.vo.GraphVO;
import com.three.cucumber.vo.MemberVO;
import com.three.cucumber.vo.PostVO;
import com.three.cucumber.vo.RepContentVO;
import com.three.cucumber.vo.ReportPostVO;
import com.three.cucumber.vo.ReportQnaVO;
import com.three.cucumber.vo.RevReportVO;

@Controller
public class AdminController {

	@Resource(name="reportPostService")
	private ReportPostService rpSer;
	
	@Resource(name="reportQnaService")
	private ReportQnaService rqSer;
	
	@Resource(name="memberService")
	private MemberService memSer;
	
	@Resource(name="reportService")
	private ReportService repSer;
	
	@Resource(name="profileService")
	private ProfileService proSer;
	
	@Resource(name="repContentService")
	private RepContentService rcSer;
	
	@Resource(name = "PostService")
	private PostService pSer;
	
	@Resource(name = "qnaService")
	private QnaService qSer;
	
	@RequestMapping(value="adminPage.do")
	public String adminPage(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		MemberVO mvo = memSer.findMem( memSer.getSession(request));
		model.addAttribute("mvo", mvo);
		return "admin/adminPage";
	}
	// �Խù� �Ű� ��ȸ ��������
	@RequestMapping(value="getEveryReportPost.do")
	public String getEveryReportPost(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		
		ArrayList<ReportPostVO> rparray = rpSer.getEveryReportPost();
		for(int i=0; i<rparray.size(); i++) {		
				rparray.get(i).setRepConArray(rpSer.getRepCnt(rparray.get(i).getPostId()));
		}
		model.addAttribute("rparray", rparray);
		return "admin/adReportPost";
	}
	@RequestMapping(value = "AdDelPost.do")
	public String AdDelPost(Integer postId) throws SQLException {
		rpSer.AdDelPost(postId);
		return "redirect:getEveryReportPost.do";
	}
	
	@RequestMapping(value = "delrepPost.do")
	public String delrepPost(Integer postId) {
		rpSer.delRepPost(postId);
		return "redirect:getEveryReportPost.do";
	}
	@RequestMapping(value="yellowPost.do")
	public void yellowPost(Model model, Integer postId) throws SQLException {
		repSer.updateMemRep(pSer.getPostVO(postId).getMemId());
	}
	
// ���� �Ű� ��ȸ ��������
	@RequestMapping(value="getEveryReportQna.do")
	public String getEveryReportQna(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ArrayList<ReportQnaVO> rqarray = rqSer.getEveryReportQna();
		for(int i=0; i<rqarray.size(); i++) {		
			rqarray.get(i).setRepConArray(rqSer.getRepConQna(rqarray.get(i).getQnaId()));
		}
		model.addAttribute("rqarray", rqarray);
		
		return "admin/adReportQna";
	}
	@RequestMapping(value="yellowQna.do")
	public void yellowQna(Model model, Integer qnaId) throws SQLException {
		repSer.updateMemRep(qSer.getMem(qnaId));
	}

	@RequestMapping(value = "member.do")
	public String member(HttpServletRequest request, Model model, String search, String sWord) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ArrayList<MemberVO> marray = null;
		if(search.equals("email"))
			marray = repSer.getMemE(sWord);
		else if(search.equals("nick"))
			marray = repSer.getMemN(sWord);
		else if(search.equals("tel"))
			marray = repSer.getMemT(sWord);	
		else
			marray = repSer.getAllMem();
		model.addAttribute("marray", marray);
		model.addAttribute("search", search);
		model.addAttribute("sWord", sWord);
		return "admin/member";
	}
	
	@RequestMapping(value = "adDelMem.do")
	public String adDelMem(Model model, Integer memId) {
		repSer.adDelMem(memId);
		return "redirect:member.do?search=no&sWord=no";
	}
	@RequestMapping(value="chatRep.do")
	public String adChatRep(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ArrayList<ChatReportVO> carray =  repSer.getAllChatRep();
		model.addAttribute("carray", carray);
		return "admin/chatRep";
	}
	
	@RequestMapping(value="delrepChat.do")
	public String delrepChat(HttpServletRequest request,Model model, Integer chatReportId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ChatReportVO cvo = repSer.findChatRep(chatReportId);
		String saveDir = request.getSession().getServletContext().getRealPath("/resources/chat_report");
		File dir = new File(saveDir);
		File[] files = dir.listFiles();
		String file = cvo.getChatReportPipath();
		for(File f:files) {
			if(f.getName().equals(file)) {
				f.delete();
			}
		}
		
		repSer.delRepChat(chatReportId);
		
		return "redirect:chatRep.do";
	}
	@RequestMapping(value="getAllRevRep.do")
	public String getAllRevRep(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ArrayList<RevReportVO> rarray = repSer.getAllRevRep();
		model.addAttribute("rarray", rarray);
		return "admin/revRep";
	}
	@RequestMapping(value="addelRev.do")
	public String delRev(HttpServletRequest request,Model model, Integer revId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		proSer.delRev(revId);
		return "redirect:getAllRevRep.do";
	}
	@RequestMapping(value="delrevRep.do")
	public String delrevRep(HttpServletRequest request,Model model, Integer revRepId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		repSer.delrevRep(revRepId);
		return "redirect:getAllRevRep.do";
	}
	@RequestMapping(value="adDelQna.do")
	public String adDelQna(HttpServletRequest request,Model model, Integer qnaId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		repSer.adDelQna(qnaId);
		repSer.delQnaRep(qnaId);
		return "redirect:getEveryReportQna.do";
	}
	@RequestMapping(value="adDelRepQna.do")
	public String adDelRepQna(HttpServletRequest request,Model model, Integer qnaId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		repSer.delQnaRep(qnaId);
		return "redirect:getEveryReportQna.do";
	}
	@RequestMapping(value="memAl.do" , method=RequestMethod.POST)
	public void memAl(Model model, Integer memId) throws SQLException {
		repSer.updateMemRep(memId);
	}
	@RequestMapping(value="adGraph.do")
	public String adGraph(HttpServletRequest request,Model model) throws SQLException {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ArrayList<GraphVO> garray = pSer.getAllGraph();
		model.addAttribute("garray", garray);
		return "/admin/adGraph";
	}
	@RequestMapping(value="upGraph.do", method=RequestMethod.POST)
	public String insertPost(GraphVO gvo ,Model model, MultipartHttpServletRequest newImg, String lastImg) 
			throws SQLException, IllegalStateException, IOException {
		MultipartFile file = newImg.getFile("newImg");
		String saveDir = newImg.getSession().getServletContext().getRealPath("/resources/graph");
		File dir = new File(saveDir);
	    if(!dir.exists()) {
	    	dir.mkdirs();
	    }
	    if(!file.isEmpty()) {

            String orifileName = file.getOriginalFilename();
            String ext = orifileName.substring(orifileName.lastIndexOf("."));          

            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-HHmmssSSS");
            int rand = (int)(Math.random()*1000);

            String reName = sdf.format(System.currentTimeMillis()) + "_" + rand + ext;
            gvo.setPipath(reName);
            try {
            	file.transferTo(new File(saveDir + "/" + reName));
            }catch (IOException e) {
                e.printStackTrace();
            }
        }
	    
	    if(lastImg != null) {
			File[] files = dir.listFiles();
			for(File f:files) {
				if(f.getName().equals(lastImg))
						f.delete();
			}
	    }
		pSer.upGraph(gvo);
		
		return "redirect:adGraph.do";
	}
	
	@RequestMapping(value="cate.do")
	public String cate(HttpServletRequest request,Model model) throws Exception {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ArrayList<CateVO> carray = pSer.getAllCate();
		ArrayList<CateVO> delCarray = pSer.getAllDelCate();
		model.addAttribute("carray", carray);
		model.addAttribute("delCarray", delCarray);
		return "/admin/cate";
	}
	
	@RequestMapping(value="checkCate.do")
	@ResponseBody
	public int checkCate(Model model, String cateName) throws SQLException {		
		return pSer.checkCate(cateName);
	}
	
	@RequestMapping(value="inCate.do")
	public String inCate(HttpServletRequest request, CateVO cvo) throws SQLException {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		pSer.inCate(cvo);
		return "redirect:cate.do";
	}
	
	@RequestMapping(value="upCate.do")
	public String upCate(HttpServletRequest request, CateVO cvo) throws SQLException {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		pSer.upCate(cvo);
		return "redirect:cate.do";
	}

	@RequestMapping(value="delCate.do")
	public String delCate(HttpServletRequest request, CateVO cvo) throws SQLException {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		pSer.delCate(cvo);
		return "redirect:cate.do";
	}
	
	
	@RequestMapping(value="repContent.do")
	public String repContent(HttpServletRequest request,Model model) throws SQLException {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ArrayList<RepContentVO> rarray = rcSer.allRepCont();
		for(int i = 0; i<rarray.size(); i++) {
			rarray.get(i).setCnt(rcSer.delCheck(rarray.get(i).getRepId()));
		}
		model.addAttribute("rarray", rarray);
		return "/admin/repContent";
	}
	
	@RequestMapping(value="checkRepCon.do")
	@ResponseBody
	public int checkRepCon(Model model, String repContent) throws SQLException {		
		return rcSer.checkRepCon(repContent);
	}
	
	@RequestMapping(value="inRepContent.do")
	public String inRepContent(HttpServletRequest request, RepContentVO rvo) throws SQLException {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		rcSer.inRepCon(rvo);
		return "redirect:repContent.do";
	}
	
	@RequestMapping(value="upRepContent.do")
	public String upRepContent(HttpServletRequest request, RepContentVO rvo) throws SQLException {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		rcSer.upRepCon(rvo);
		return "redirect:repContent.do";
	}

	@RequestMapping(value="delRepContent.do")
	public String delRepContent(HttpServletRequest request, RepContentVO rvo) throws SQLException {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		rcSer.delRepCon(rvo);
		return "redirect:repContent.do";
	}
	
	@RequestMapping(value="upMemRep.do")
	public String upMemRep(HttpServletRequest request, MemberVO mvo) throws SQLException {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesAd")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		memSer.upReport(mvo);
		return "redirect:member.do?search=no&sWord=no";
	}
}
