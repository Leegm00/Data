package repository;

public class SQLExceptioned extends Exception {

}
