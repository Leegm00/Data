package a;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import repository.StoreDAO;
import repository.StoreVO;

public class AdminStore extends JFrame implements ActionListener {

	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
//			System.setProperty("file.encoding", "UTF-8");
			public void run() {
				try {
					AdminStore frame = new AdminStore();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private static final long serialVersionUID = 1L;
	private JTable table;
	private DefaultTableModel model;
	private JButton deleteButton;
	private JButton updateButton;
	private JButton insertButton;
	private JButton btnAll;
	private JButton btn1;
	private JButton btn2;
	private JButton btn3;
	private JButton btn4;
	private StoreDAO storeDAO;

	public AdminStore() {

		setTitle("가게 관리");
		setSize(800, 400);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);

		// StoreDAO 인스턴스 생성
		storeDAO = new StoreDAO();

		// JTable 생성
		table = new JTable();
		table.setRowHeight(30); // 행의 높이를 30으로 설정
		model = new DefaultTableModel(new Object[][] {}, new String[] { "가게 아이디", "가게 이름", "주소", "전화번호", "추천 수" }) {
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isCellEditable(int row, int column) {
				//  열은 수정 불가능하도록 설정
				return column >=5;
			}
		};
		// 각 컬럼의 넓이 설정
		table.setModel(model);

		// JScrollPane으로 JTable 감싸기
		JScrollPane scrollPane = new JScrollPane(table);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		JPanel panel = new JPanel();

		// 전체
		btnAll = new JButton("전체");
		btnAll.addActionListener(this);
		panel.add(btnAll);
		getContentPane().add(panel, BorderLayout.SOUTH);
		// 한식
		btn1 = new JButton("한식");
		btn1.addActionListener(this);
		panel.add(btn1);
		getContentPane().add(panel, BorderLayout.SOUTH);
		// 중식
		btn2 = new JButton("중식");
		btn2.addActionListener(this);
		panel.add(btn2);
		getContentPane().add(panel, BorderLayout.SOUTH);
		// 일식
		btn3 = new JButton("일식");
		btn3.addActionListener(this);
		panel.add(btn3);
		getContentPane().add(panel, BorderLayout.SOUTH);
		// 양식
		btn4 = new JButton("양식");
		btn4.addActionListener(this);
		panel.add(btn4);
		getContentPane().add(panel, BorderLayout.SOUTH);
		// 추가버튼
		insertButton = new JButton("추가");
		insertButton.addActionListener(this);
		panel.add(insertButton);
		getContentPane().add(panel, BorderLayout.SOUTH);
		// 수정버튼
		updateButton = new JButton("수정");
		updateButton.addActionListener(this);
		panel.add(updateButton);
		getContentPane().add(panel, BorderLayout.SOUTH);

		// 삭제 버튼 추가
		deleteButton = new JButton("삭제");
		deleteButton.addActionListener(this);
		panel.add(deleteButton);
		getContentPane().add(panel, BorderLayout.SOUTH);
		// 가로 사이즈 설정
		table.getColumnModel().getColumn(0).setPreferredWidth(40);
		table.getColumnModel().getColumn(1).setPreferredWidth(150);
		table.getColumnModel().getColumn(2).setPreferredWidth(250);
		table.getColumnModel().getColumn(3).setPreferredWidth(150);
		table.getColumnModel().getColumn(4).setPreferredWidth(20);

		// 전체 가게조회
		List<StoreVO> storeList = storeDAO.getMenuAll();
		for (StoreVO store : storeList) {
			Object[] row = { store.getStore_id(), store.getStore_name(), store.getAddress(), store.getTel(),
					store.getRec_cnt(), store.getRec_cnt() };
			model.addRow(row);

		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == deleteButton) {// 가게 삭제
			int selectedRow = table.getSelectedRow(); // 행 선택
			if (selectedRow != -1) {// 선택이 되었다면 종속문장 실행
				String storeName = (String) model.getValueAt(selectedRow, 1); // 가게 이름을 가져옴
				int confirm = JOptionPane.showConfirmDialog(this, "정말로 삭제하시겠습니까?", "확인", JOptionPane.YES_NO_OPTION);
				if (confirm == JOptionPane.YES_OPTION) { // yes를 클릭한경우 종속문장 실행
					try { // 삭제 쿼리 실행
						storeDAO.deleteStore(storeName);
						model.removeRow(selectedRow);
						JOptionPane.showMessageDialog(null, "삭제되었습니다.");
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			}
		} else if (e.getSource() == updateButton) {// 가게 이름 수정
			int selectedRow = table.getSelectedRow();
			if (selectedRow != -1) {
				String storeName = (String) model.getValueAt(selectedRow, 1);

				// 사용자가 수정할 값을 입력받음
				String newStoreName = JOptionPane.showInputDialog(this, "새로운 가게 이름을 입력하세요.");

				// 입력받은 값이 null이 아니면, 즉 사용자가 값을 입력한 경우 종속문장 실행
				if (newStoreName != null) {
					// 수정 쿼리 실행
					storeDAO.updateStore(storeName, newStoreName);
					model.setValueAt(newStoreName, selectedRow, 1);
					JOptionPane.showMessageDialog(null, "수정되었습니다.");
				}
			}

		} else if (e.getSource() == btnAll) {
			model.setRowCount(0);
			List<StoreVO> storeList = storeDAO.getMenuAll();
			for (StoreVO store : storeList) {
				Object[] row = { store.getStore_id(), store.getStore_name(), store.getAddress(), store.getTel(),
						store.getRec_cnt(), store.getRec_cnt() };
				model.addRow(row);
			}
		} else if (e.getSource() == insertButton) {
			// 사용자가 수정할 값을 입력받음
			String storeName = JOptionPane.showInputDialog(this, "새로운 가게 이름을 입력하세요.");
			String address = JOptionPane.showInputDialog(this, "새로운 가게 주소를 입력하세요.");
			String tel = JOptionPane.showInputDialog(this, "새로운 가게 전화번호를 입력하세요.");
			String[] options = { "한식", "중식", "일식", "양식" };
			int cat_id = (JOptionPane.showOptionDialog(null, "추가할 식당의 카테고리를 선택해주세요", "식당 카테고리 선택",
					JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0])) + 1;

			while (storeName == null || address == null || tel == null || cat_id <= 0) {
				JOptionPane.showMessageDialog(null, "모든 항목을 입력해주세요.");
				storeName = JOptionPane.showInputDialog(this, "새로운 가게 이름을 입력하세요.");
				if (storeName == null) {
					JOptionPane.showMessageDialog(null, "사용자가 취소하였습니다.");
					break;
				} // 입력 창이 닫힐 경우 바로 반복문을 빠져나옴
				address = JOptionPane.showInputDialog(this, "새로운 가게 주소를 입력하세요.");
				if (address == null) {
					JOptionPane.showMessageDialog(null, "사용자가 취소하였습니다.");
					break;
				}
				tel = JOptionPane.showInputDialog(this, "새로운 가게 전화번호를 입력하세요.");
				if (tel == null) {
					JOptionPane.showMessageDialog(null, "사용자가 취소하였습니다.");
					break;
				}
				cat_id = JOptionPane.showOptionDialog(null, "추가할 식당의 카테고리를 선택해주세요", "식당 카테고리 선택",
						JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
				if (cat_id <= 0) {
					JOptionPane.showMessageDialog(null, "카테고리를 선택해주세요.");
				}
			}

			// 입력받은 값이 null이 아니면, 즉 사용자가 값을 입력한 경우 종속문장 실행
			if (storeName != null && address != null && tel != null && cat_id >= 0) {
				
				storeDAO.insertStore(storeName, address, tel, cat_id);
				model.setRowCount(0);
				List<StoreVO> storeList = storeDAO.getMenuAll();
				for (StoreVO store : storeList) {
				    Object[] row = { store.getStore_id(), store.getStore_name(), store.getAddress(), store.getTel(),
				        store.getRec_cnt(), store.getRec_cnt() };
				    model.addRow(row);
				}
				}

			}
		

		else if (e.getSource() == btn1)

		{// 한식 출력
			model.setRowCount(0);
			List<StoreVO> storeList = storeDAO.getMenu1();
			for (StoreVO store : storeList) {
				Object[] row = { store.getStore_id(), store.getStore_name(), store.getAddress(), store.getTel(),
						store.getRec_cnt(), store.getRec_cnt() };
				model.addRow(row);
			}
		} else if (e.getSource() == btn2) {// 중식 출력
			model.setRowCount(0);
			List<StoreVO> storeList = storeDAO.getMenu2();
			for (StoreVO store : storeList) {
				Object[] row = { store.getStore_id(), store.getStore_name(), store.getAddress(), store.getTel(),
						store.getRec_cnt(), store.getRec_cnt() };
				model.addRow(row);
			}
		} else if (e.getSource() == btn3) {// 일식 출력
			model.setRowCount(0);
			List<StoreVO> storeList = storeDAO.getMenu3();
			for (StoreVO store : storeList) {
				Object[] row = { store.getStore_id(), store.getStore_name(), store.getAddress(), store.getTel(),
						store.getRec_cnt(), store.getRec_cnt() };
				model.addRow(row);
			}
		} else if (e.getSource() == btn4) {// 양식 출력
			model.setRowCount(0);
			List<StoreVO> storeList = storeDAO.getMenu4();
			for (StoreVO store : storeList) {
				Object[] row = { store.getStore_id(), store.getStore_name(), store.getAddress(), store.getTel(),
						store.getRec_cnt(), store.getRec_cnt() };
				model.addRow(row);
			}
		}
	}

}
