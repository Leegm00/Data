package a;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Admin extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
//		System.setProperty("file.encoding", "UTF-8");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin frame = new Admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin() {
		setTitle("관리자 모드");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 439, 406);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitle = new JLabel("AdminPage");
		lblTitle.setFont(new Font("굴림", Font.PLAIN, 54));
		lblTitle.setBounds(0, 10, 340, 64);
		contentPane.add(lblTitle);
		
		JButton btnMember = new JButton("회원 관리");
		btnMember.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AdminMember adminMember = new AdminMember(); // Register 클래스의 인스턴스 생성
				adminMember.setVisible(true);
			}
		});
		btnMember.setFont(new Font("굴림", Font.PLAIN, 21));
		btnMember.setBounds(25, 128, 171, 83);
		contentPane.add(btnMember);
		
		JButton btnMenu = new JButton("매장 관리");
		btnMenu.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AdminStore storeTableGUI = new AdminStore(); // Register 클래스의 인스턴스 생성
				storeTableGUI.setVisible(true);
			}
		});
		btnMenu.setFont(new Font("굴림", Font.PLAIN, 21));
		btnMenu.setBounds(221, 128, 171, 83);
		contentPane.add(btnMenu);
	}

}
