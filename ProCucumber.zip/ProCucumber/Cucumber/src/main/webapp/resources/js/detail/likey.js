var postId=0;
var qnaId=0;

function qnaCheck() {
		if (document.qnaForm.qnaContent.value == "") {
			alert("댓글이 입력되지 않았습니다")
			return false;
		}
		return true;
	}
	
	function replyCheck() {
		if (document.replyForm.qnaContent.value == "") {
			alert("답글이 입력되지 않았습니다")
			return false;
		}
		return true;
	}
	
	function reportCheck() {
		if (confirm('정말 신고하시겠습니까?') == true) {
			alert("신고되었습니다");
		} else {
			return false;
		}
}

function likey(postId) {
	$.ajax ({
			url : "likey.do",
			type : 'GET',
			data : {
						postId : postId
					},
			success : function(data){
				//var li = Number(document.getElementById('pl').innerText);

				if(data == 1) {
					alert("찜 하셨습니다");
					if(document.getElementById('likey1'))
						document.getElementById('likey1').src= "resources/img/filledlikey.svg";
					if(document.getElementById('likey2'))
						document.getElementById('likey2').src= "resources/img/filledlikey.svg";
					//document.getElementById('pl').innerText = li+1;
				}
				else {
					alert("찜 취소되었습니다");
					if(document.getElementById('likey1'))
						document.getElementById('likey1').src= "resources/img/likey.svg";
					if(document.getElementById('likey2'))
						document.getElementById('likey2').src= "resources/img/likey.svg";
					//document.getElementById('pl').innerText = li -1;
				}
			}
		});
}
		

function delQna(qnaId, postId, depth){
	if(window.confirm('댓글을 삭제하시겠습니까?')) {
		location.href='delQna.do?qnaId='+qnaId+'&postId='+postId+'&depth='+depth;
	}
}

function mention(e) {
	var nick = e.parentElement.previousElementSibling.innerText;
	var tags = e.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.lastElementChild.firstElementChild.firstElementChild.firstElementChild;
	tags.innerText = "@"+nick;
	tags.nextElementSibling.firstElementChild.focus();
}

function delmention(e) {
	e.innerText = '';
}

function inQnaRe(e){
	var men = e.parentElement.previousElementSibling.innerText;
	e.parentElement.nextElementSibling.value = men;
	e.parentElement.parentElement.submit();
}

function block(blocked, postId) {
	var blocked = blocked;
	var detpost = postId;
	if(window.confirm("차단을 하면 해당 회원의 게시물과 \n댓글, 채팅이 보이지 않고 알림도 발송되지 않습니다")){
		location.href="detBlock.do?blocked="+blocked+"&postId="+detpost;
	}
		
}

function postRep(id) {
	postId = id;
}
function qnaRep(post, qna){
	postId = post;
	qnaId = qna;
}
function report() {
	document.getElementById("repPostId").value = postId;
	document.getElementById("repQnaId").value = qnaId;
	alert("신고완료 되었습니다")
	document.getElementById("reportForm").submit();
}