function handleOnChange(e) {
	// 선택된 데이터의 텍스트값 가져오기
	const text = e.options[e.selectedIndex].text;		  
	// 선택한 텍스트 출력
	document.getElementById('up').value = text;
}
function chRepCon(type) {
	var repContent = document.getElementById(type).value;
	if(repContent == '') {
		alert('내용을 입력해 주세요');
		return false;
	}
	else{
		$.ajax({
			type : 'post',
			url : "checkRepCon.do",
			data : {
				repContent : repContent
			},
			success : function (data) {
				if(data != 0) {
					alert('이미 존재하는 신고메뉴입니다');
					return false;
				}
				else
					document.getElementById(type+'Form').submit();
			}					
		}); // end ajax
	}
}
function delCheck() {
	var repId = document.getElementById('del').value;
	if(repId == 0){
		alert('삭제할 신고메뉴를 선택해 주세요');
		return false;
	}
	else 
		document.getElementById('delForm').submit();
}
