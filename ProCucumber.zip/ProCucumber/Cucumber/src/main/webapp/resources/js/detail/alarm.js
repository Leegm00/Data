function delCheck(){
	if(window.confirm("선택된 알림을 삭제하시겠습니까?")) {
    	var arr = [];
        document.querySelectorAll("input[name=ach]:checked").forEach(function (item) {
        	var alarmId = item.value;
        	arr.push(alarmId);
        	item.parentElement.parentElement.remove();
        });
        $.ajax({
			type : "post",
			url : "delAl.do",
			traditional: true, //배열 보낼시 사용
			data : {alarmIdar:arr},
			success : function(status) {						
				alert('알람이 삭제되었습니다');
			},
			error : function(status) {
				console.log(status);
			}
		});
	}
}

function delAll(){
	if(window.confirm('모든 알람을 삭제 하시겠습니까?'))
		location.href="delAllAl.do";
}