package jTableButtonRenderer;

import java.awt.Component;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import a.Index;
import repository.StoreDAO;


public class JTableButtonRenderer extends JButton implements TableCellRenderer {
	ImageIcon like;
	private boolean isRec;
	Index index = new Index();

	public JTableButtonRenderer() {
		setOpaque(true);
	}

	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		like = new ImageIcon(getClass().getResource("like.png"));
		String memid  = index.getMemid();
		StoreDAO sdao = new StoreDAO();
		String storeName = (String) table.getValueAt(row, 0);
		int storeId = sdao.getStoreId(storeName);
		int recStoreId = 0;
		try {
			recStoreId = sdao.recStore_rs(memid, storeId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		if (recStoreId==storeId) {
			like = new ImageIcon(getClass().getResource("unlike.png"));
		}
		
		setIcon(like);
		return this;
	}
}