package service;

import java.sql.SQLException;

import repository.DAO;
import repository.IdPasswordException;
import repository.Member;
import repository.MemberAlreadyException;
import repository.MemberNotFoundException;
import repository.PasswordNotMatchedException;

public class Service {
private DAO memberDao = new DAO(); //의존 객체 생성
	
	//회원가입
	public void register(String id, String pw, String pw2, String gender,String email, String tel,String avg) throws MemberAlreadyException, PasswordNotMatchedException {
		if(!pw.equals(pw2)) {
			System.out.println("비밀번호 확인 필요");
			throw new PasswordNotMatchedException();
		}else {
			Member member = new Member(id, pw,gender,email,tel, avg);
			memberDao.memberInsert(member);
		}
	}
	
	//로그인
	public Member login(String id, String pw) throws IdPasswordException, MemberNotFoundException {
		Member member = memberDao.memberSelectOne(id);
		if(member == null) {
			throw new MemberNotFoundException();
		}
		if(!member.getPw().equals(pw)) {
			throw new IdPasswordException();
		}
		return member;
	}
//	//회원정보 수정
//		public void editPassword(String id, String oldPwd, String newPwd) {
//			Member member = memberDao.memberSelectOne(id);
//			if(member == null) {
//				throw new MemberNotFoundException();
//			}
//			if(!member.getPw().equals(oldPwd)) {
//				throw new IdPasswordException();
//			}
//			memberDao.memberPwModify(member.getNum(), newPwd);
//		}
//		
		//회원 탈퇴
		public void remove(String id, String pw) throws MemberNotFoundException, IdPasswordException, SQLException, MemberAlreadyException {
			Member member = memberDao.memberSelectOne(id);
			if(member == null) {
				throw new MemberNotFoundException();
			}
			if(!member.getPw().equals(pw)) {
				throw new IdPasswordException();
			}
			memberDao.memberDelete(member.getMem_id());
		}
}
