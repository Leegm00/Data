package a;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import jTableButtonModel.JTableButtonModel;
import jTableButtonRenderer.JTableButtonRenderer;
import repository.StoreDAO;
import repository.StoreVO;

public class StoreMain extends JFrame implements ActionListener {

	public static void main(String args[]) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StoreMain frame = new StoreMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private static final long serialVersionUID = 1L;
	public static JTable table;
	private JButton btn1;
	private JButton btn2;
	private JButton btn3;
	private JButton btn4;
	private StoreDAO storeDAO;
	public static DefaultTableModel model;
	public JTableButtonModel jtbmodel;

	private String[] ages = { "���ɴ�", "10��", "20��", "30��", "40��", "50�� �̻�" };
	private String[] genders = { "����", "M", "F" };

	JComboBox<String> ageCombo = new JComboBox<String>(ages);
	JComboBox<String> genCombo = new JComboBox<String>(genders);
	private DefaultComboBoxModel<String> ageModel = new DefaultComboBoxModel<>(ages);
	private JLabel ageLabel = new JLabel("���ɴ�");

	public StoreMain() throws ClassNotFoundException, SQLException {

		setTitle("��õ ���� ���");
		setSize(1000, 550);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);

		// StoreDAO �ν��Ͻ� ����
		storeDAO = new StoreDAO();

		// JTable ����
		TableCellRenderer tableRenderer;
		table = new JTable();
		table.setRowHeight(30); // ���� ���̸� 30���� ����
		model = new DefaultTableModel(new Object[][] {}, new String[] { "���� �̸�", "�ּ�", "��ȭ��ȣ", "��õ��", "��õ" }) {
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isCellEditable(int row, int column) {
				// ���� ���� �Ұ����ϵ��� ����
				return column >= 4;
			}
		};
		// �� �÷��� ���� ����
		table.setModel(model);

		// JScrollPane���� JTable ���α�
		JScrollPane scrollPane = new JScrollPane(table);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		JPanel panel = new JPanel();

		// ��õ�� ����

		TableRowSorter<TableModel> sorter = new TableRowSorter<>(table.getModel());
		table.setRowSorter(sorter);
		List<RowSorter.SortKey> sortKeys = new ArrayList<>();
		int columnIndexToSort = 3;
		sortKeys.add(new RowSorter.SortKey(3, SortOrder.DESCENDING));
		sorter.setSortKeys(sortKeys);
		sorter.sort();
//-----------------------
		table.getColumn("��õ").setCellRenderer(new JTableButtonRenderer());
		table.getColumn("��õ").setCellEditor(new JTableButtonModel(storeDAO));

//-----------------------

		// �ѽ�
		btn1 = new JButton("�ѽ�");
		btn1.addActionListener(this);
		panel.add(btn1);
		getContentPane().add(panel, BorderLayout.NORTH);
		// �߽�
		btn2 = new JButton("�߽�");
		btn2.addActionListener(this);
		panel.add(btn2);
		getContentPane().add(panel, BorderLayout.NORTH);
		// �Ͻ�
		btn3 = new JButton("�Ͻ�");
		btn3.addActionListener(this);
		panel.add(btn3);
		getContentPane().add(panel, BorderLayout.NORTH);
		// ���
		btn4 = new JButton("���");
		btn4.addActionListener(this);
		panel.add(btn4);
		getContentPane().add(panel, BorderLayout.NORTH);

		ageCombo.setName("���ɴ�");
		ageCombo = new JComboBox<String>(ages);
		ageCombo.setBounds(550, 21, 64, 20);
		ageCombo.addActionListener(this);
		panel.add(ageCombo);
		getContentPane().add(panel, BorderLayout.NORTH);

		genCombo.setName("����");
		genCombo = new JComboBox<String>(genders);
		genCombo.setBounds(660, 21, 64, 20);
		genCombo.addActionListener(this);
		panel.add(genCombo);
		getContentPane().add(panel, BorderLayout.NORTH);

		// ���� ������ ����
		table.getColumnModel().getColumn(0).setPreferredWidth(160);
		table.getColumnModel().getColumn(1).setPreferredWidth(280);
		table.getColumnModel().getColumn(2).setPreferredWidth(80);
		table.getColumnModel().getColumn(3).setPreferredWidth(15);
		table.getColumnModel().getColumn(4).setPreferredWidth(15);

		// ��ü ������ȸ
//		List<StoreVO> storeList = storeDAO.getMenuAll();
//		for (StoreVO store : storeList) {
//			Object[] row = { store.getStore_name(), store.getAddress(), store.getTel(),
//					store.getRec_cnt()};
//			model.addRow(row);
		List<StoreVO> storeList = storeDAO.getMenu1();
		for (StoreVO store : storeList) {
			Object[] row = { store.getStore_name(), store.getAddress(), store.getTel(), store.getRec_cnt() };
			model.addRow(row);
		}
		// ��������
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 1) {
					JTable table = (JTable) e.getSource();
					int row = table.getSelectedRow();
					String store_name = (String) table.getValueAt(row, 0);
					String address = (String) table.getValueAt(row, 1);
					String tel = (String) table.getValueAt(row, 2);
					Integer rec_cnt = (Integer) table.getValueAt(row, 3);

					// ���̾�α� ���� �г� ����
					JPanel panel = new JPanel();
					panel.setLayout(new BorderLayout());

					JPanel left = new JPanel();
					left.setLayout(new GridLayout(4, 2));

					JLabel nameLabel = new JLabel("���� �̸� : " + store_name);
					nameLabel.setFont(new Font("SansSerif", Font.BOLD, 25));
					left.add(nameLabel);

					JLabel lbladdr = new JLabel("�ּ� : " + address);
					lbladdr.setFont(new Font("SansSerif", Font.PLAIN, 16));
					left.add(lbladdr);
					JLabel lbltel = new JLabel("��ȭ��ȣ : " + tel);
					lbltel.setFont(new Font("SansSerif", Font.PLAIN, 16));
					left.add(lbltel);

					JLabel lblrec = new JLabel("��õ �� : " + rec_cnt.toString());
					lblrec.setFont(new Font("SansSerif", Font.PLAIN, 16));
					left.add(lblrec);

					panel.add(left, BorderLayout.WEST);
					JPanel topPanel = new JPanel();
					JLabel lblreserve = new JLabel("���� �ð� : ");
					String[] reserveS = { "10:00~11:00", "11:00~12:00", "12:00~13:00", "13:00~14:00", "14:00~15:00 ",
							"15:00~16:00", "16:00~17:00", "17:00~18:00", "18:00~19:00", "19:00~20:00" };
					JComboBox<String> reserve = new JComboBox<String>(reserveS);
					topPanel.add(lblreserve);
					topPanel.add(reserve);
					panel.add(topPanel, BorderLayout.NORTH);

					// ���� �г� ����
					JPanel rightPanel = new JPanel();
					ImageIcon icon = new ImageIcon(getClass().getResource("image.png"));
					JLabel iconLabel = new JLabel(icon);
					iconLabel.setPreferredSize(new Dimension(150, 150));
					rightPanel.add(iconLabel);
					panel.add(rightPanel, BorderLayout.EAST);

					// �ϴ� �г� ����
					JPanel bottomPanel = new JPanel();
					JButton cancelButton = new JButton("�ݱ�");
					cancelButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							JOptionPane.getRootFrame().dispose(); // ���̾�α� â �ݱ�
						}
					});
					bottomPanel.add(cancelButton);
					JButton reserveButton = new JButton("�����ϱ�");
					reserveButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							// ���� form
							JPanel leftre = new JPanel();
							JPanel panelre = new JPanel();
							panelre.setLayout(new BorderLayout());

							Box leftBox = Box.createVerticalBox();

							JLabel lblinfo = new JLabel("�Ʒ��� ���� ������ Ȯ�����ּ���");
							lblinfo.setFont(new Font("SansSerif", Font.BOLD, 22));
							leftBox.add(lblinfo);

							JLabel nameLabel = new JLabel("���� �̸� : " + store_name);
							nameLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
							leftBox.add(nameLabel);

							JLabel lbladdr = new JLabel("�ּ� : " + address);
							lbladdr.setFont(new Font("SansSerif", Font.PLAIN, 16));
							leftBox.add(lbladdr);

							JLabel lbltel = new JLabel("��ȭ��ȣ : " + tel);
							lbltel.setFont(new Font("SansSerif", Font.PLAIN, 16));
							leftBox.add(lbltel);

							JLabel lbltime = new JLabel("���� �ð� : " + (String) reserve.getSelectedItem());
							lbltime.setFont(new Font("SansSerif", Font.BOLD, 16));
							leftBox.add(lbltime);

							leftre.add(leftBox);

							panelre.add(leftre, BorderLayout.WEST);
							JPanel bottomPanelre = new JPanel();
							panelre.add(bottomPanelre, BorderLayout.SOUTH);
							
							JButton okbtn = new JButton("Ȯ��");
							okbtn.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									JOptionPane.showMessageDialog(null, "������ �Ϸ�Ǿ����ϴ�!");
									JOptionPane.getRootFrame().dispose(); // ���̾�α� â �ݱ�
								}
							});
							bottomPanelre.add(okbtn);
							JOptionPane.showOptionDialog(null, panelre, "���� ����", JOptionPane.DEFAULT_OPTION,
									JOptionPane.PLAIN_MESSAGE, null, new Object[] {}, null);
							panelre.setPreferredSize(new Dimension(300, 200));
						}
					});
					bottomPanel.add(reserveButton);
					panel.add(bottomPanel, BorderLayout.SOUTH);

					panel.setPreferredSize(new Dimension(650, 200));
					// ���̾�α� ǥ��
					JOptionPane.showOptionDialog(null, panel, "���� ����", JOptionPane.DEFAULT_OPTION,
							JOptionPane.PLAIN_MESSAGE, null, new Object[] {}, null);
				}
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String selectedAge = (String) ageCombo.getSelectedItem();
		String selectedGender = (String) genCombo.getSelectedItem();

		if (e.getSource() == btn1) {// �ѽ� ���
			model.setRowCount(0);
			List<StoreVO> storeList;
			storeList = storeDAO.getMenu1();
			if (selectedAge == "10��" && selectedGender == "M") // ���� & ����
				storeList = storeDAO.getMenuAll(1, "10��", "M");
			else if (selectedAge == "10��" && selectedGender == "F")
				storeList = storeDAO.getMenuAll(1, "10��", "F");
			else if (selectedAge == "10��")
				storeList = storeDAO.getMenuAge(1, "10��");
			else if (selectedAge == "20��")
				storeList = storeDAO.getMenuAge(1, "20��");
			else if (selectedAge == "30��")
				storeList = storeDAO.getMenuAge(1, "30��");
			else if (selectedAge == "40��")
				storeList = storeDAO.getMenuAge(1, "40��");
			else if (selectedAge == "50�� �̻�")
				storeList = storeDAO.getMenuAge(1, "50�� �̻�");
			else if (selectedGender == "M")
				storeList = storeDAO.getMenuGender(1, "M");// ����
			else if (selectedGender == "F")
				storeList = storeDAO.getMenuGender(1, "F");// ����
			for (StoreVO store : storeList) {
				Object[] row = { store.getStore_name(), store.getAddress(), store.getTel(), store.getRec_cnt() };
				model.addRow(row);
			}
		} else if (e.getSource() == btn2) {// �߽� ���
			model.setRowCount(0);
			List<StoreVO> storeList;
			storeList = storeDAO.getMenu2();
			if (selectedAge == "10��" && selectedGender == "M") // ���� & ����
				storeList = storeDAO.getMenuAll(2, "10��", "M");
			else if (selectedAge == "10��" && selectedGender == "F")
				storeList = storeDAO.getMenuAll(2, "10��", "F");
			else if (selectedAge == "10��")
				storeList = storeDAO.getMenuAge(2, "10��");
			else if (selectedAge == "20��")
				storeList = storeDAO.getMenuAge(2, "20��");
			else if (selectedAge == "30��")
				storeList = storeDAO.getMenuAge(2, "30��");
			else if (selectedAge == "40��")
				storeList = storeDAO.getMenuAge(2, "40��");
			else if (selectedAge == "50�� �̻�")
				storeList = storeDAO.getMenuAge(2, "50�� �̻�");
			else if (selectedGender == "M")
				storeList = storeDAO.getMenuGender(2, "M");// ����
			else if (selectedGender == "F")
				storeList = storeDAO.getMenuGender(2, "F");// ����
			for (StoreVO store : storeList) {
				Object[] row = { store.getStore_name(), store.getAddress(), store.getTel(), store.getRec_cnt() };
				model.addRow(row);
			}
		} else if (e.getSource() == btn3) {// �߽� ���
			model.setRowCount(0);
			List<StoreVO> storeList;
			storeList = storeDAO.getMenu3();
			if (selectedAge == "10��" && selectedGender == "M") // ���� & ����
				storeList = storeDAO.getMenuAll(3, "10��", "M");
			else if (selectedAge == "10��" && selectedGender == "F")
				storeList = storeDAO.getMenuAll(3, "10��", "F");
			else if (selectedAge == "10��")
				storeList = storeDAO.getMenuAge(3, "10��");
			else if (selectedAge == "20��")
				storeList = storeDAO.getMenuAge(3, "20��");
			else if (selectedAge == "30��")
				storeList = storeDAO.getMenuAge(3, "30��");
			else if (selectedAge == "40��")
				storeList = storeDAO.getMenuAge(3, "40��");
			else if (selectedAge == "50�� �̻�")
				storeList = storeDAO.getMenuAge(3, "50�� �̻�");
			else if (selectedGender == "M")
				storeList = storeDAO.getMenuGender(3, "M");// ����
			else if (selectedGender == "F")
				storeList = storeDAO.getMenuGender(3, "F");// ����
			for (StoreVO store : storeList) {
				Object[] row = { store.getStore_name(), store.getAddress(), store.getTel(), store.getRec_cnt() };
				model.addRow(row);
			}
		} else if (e.getSource() == btn4) {// �߽� ���
			model.setRowCount(0);
			List<StoreVO> storeList;
			storeList = storeDAO.getMenu4();
			if (selectedAge == "10��" && selectedGender == "M") // ���� & ����
				storeList = storeDAO.getMenuAll(4, "10��", "M");
			else if (selectedAge == "10��" && selectedGender == "F")
				storeList = storeDAO.getMenuAll(4, "10��", "F");
			else if (selectedAge == "10��")
				storeList = storeDAO.getMenuAge(4, "10��");
			else if (selectedAge == "20��")
				storeList = storeDAO.getMenuAge(4, "20��");
			else if (selectedAge == "30��")
				storeList = storeDAO.getMenuAge(4, "30��");
			else if (selectedAge == "40��")
				storeList = storeDAO.getMenuAge(4, "40��");
			else if (selectedAge == "50�� �̻�")
				storeList = storeDAO.getMenuAge(4, "50�� �̻�");
			else if (selectedGender == "M")
				storeList = storeDAO.getMenuGender(4, "M");// ����
			else if (selectedGender == "F")
				storeList = storeDAO.getMenuGender(4, "F");// ����
			for (StoreVO store : storeList) {
				Object[] row = { store.getStore_name(), store.getAddress(), store.getTel(), store.getRec_cnt() };
				model.addRow(row);
			}
		}
	}
}
