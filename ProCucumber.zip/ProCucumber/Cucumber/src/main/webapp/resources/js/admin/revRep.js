function delRev(e) {
	if(window.confirm('리뷰를 삭제하시겠습니까'))
		location.href="addelRev.do?revId="+e;
	else return false;
}

function delRepRev(e){
	if(window.confirm('신고를 삭제하시겠습니까?'))
		location.href="delrevRep.do?revRepId="+e;
	else return false;
}
function yellowWriter(e) {
	if(window.confirm('리뷰를 작성한 회원 경고를 진행하시겠습니까')){
		$.ajax({
			type : 'post',
			url : "memAl.do",
			data : {
				memId : e
			},
			success : function (data) {
				alert("리뷰를 작성한 경고가 완료되었습니다");
			}					
		}); // end ajax
	}
	else return false;
}
function yellowReporter(e) {
	if(window.confirm('신고를 한 회원 경고를 진행하시겠습니까')){
		$.ajax({
			type : 'post',
			url : "memAl.do",
			data : {
				memId : e
			},
			success : function (data) {
				alert("신고한 회원에게 경고가 완료되었습니다");
			}					
		}); // end ajax
	}
	else return false;
}