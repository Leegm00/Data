package com.three.cucumber.serviceImpl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.three.cucumber.service.AlarmService;
import com.three.cucumber.service.dao.AlarmDAO;
import com.three.cucumber.vo.AlarmVO;

@Service("alarmService")
public class AlarmServiceImpl implements AlarmService{

	@Autowired
	private AlarmDAO alarmDAO;

	@Override
	public void insertAlQna(AlarmVO avo) {
		alarmDAO.insertAlQna(avo);
		
	}

	public void delBuyAl(int buyId) {
		alarmDAO.delBuyAl(buyId);
	}
	@Override
	public int getChatAlCnt(AlarmVO avo) {
		// TODO Auto-generated method stub
		return alarmDAO.getChatAlCnt(avo);
	}

	@Override
	public void delChatAl(AlarmVO avo) {
		alarmDAO.delChatAl(avo);
		
	}

	@Override
	public int getMeetAlCnt(AlarmVO avo) {
		// TODO Auto-generated method stub
		return alarmDAO.getMeetAlCnt(avo);
	}

	@Override
	public void upMeetAl(AlarmVO avo) {
		alarmDAO.upMeetAl(avo);
		
	}

	@Override
	public ArrayList<AlarmVO> getAllAl(int session) {
		// TODO Auto-generated method stub
		return alarmDAO.getAllAl(session);
	}

	@Override
	public void delAllAl(int memId) {
		// TODO Auto-generated method stub
		alarmDAO.delAllAl(memId);
	}

	@Override
	public void delAl(Integer alarmId) {
		// TODO Auto-generated method stub
		alarmDAO.delAl(alarmId);
	}
}
