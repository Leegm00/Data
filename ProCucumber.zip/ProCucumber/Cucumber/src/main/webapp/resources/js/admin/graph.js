function up() {
	if(!window.confirm('이미지를 업로드 합니다'))
		return false;
}
