package repository;

import java.time.LocalDate;

public class Member {
	private String mem_id;
	private String pw;
	private String age;
	private String gender;
	private String tel;
	private String email;
	
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Member(String mem_id, String pw, String gender,  String email,String tel, String age) {
		super();
		this.mem_id = mem_id;
		this.pw = pw;
		this.age = age;
		this.gender = gender;
		this.tel = tel;
		this.email = email;
	}
	public Member() {
		// TODO Auto-generated constructor stub
	}
	
}







