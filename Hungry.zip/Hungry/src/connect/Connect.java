package connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connect {

	private Connection con;
	
	public Connection getConnection() { // �젒�냽媛앹껜瑜� 爰쇰궡�뒗 硫붿냼�뱶
		return con;
	}
	
	public Connect() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
	}
}
