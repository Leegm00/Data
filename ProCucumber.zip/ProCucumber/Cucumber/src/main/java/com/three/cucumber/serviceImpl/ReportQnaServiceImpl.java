package com.three.cucumber.serviceImpl;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.three.cucumber.service.MemberService;
import com.three.cucumber.service.QnaService;
import com.three.cucumber.service.ReportQnaService;
import com.three.cucumber.service.dao.ReportQnaDAO;
import com.three.cucumber.vo.QnaVO;
import com.three.cucumber.vo.RepContentVO;
import com.three.cucumber.vo.ReportQnaVO;

@Service("reportQnaService")
public class ReportQnaServiceImpl implements ReportQnaService {

	@Autowired
	private ReportQnaDAO rqdao;
	
	@Resource(name = "memberService")
	private MemberService mSer;
	
	@Resource(name = "qnaService")
	private QnaService qSer;
	
	@Override
	public void reportInsertofQna(ReportQnaVO rqvo) {
		// TODO Auto-generated method stub
		int cnt = rqdao.repQnaCh(rqvo);
		if(cnt == 0)
			rqdao.reportInsertofQna(rqvo);
	}

	@Override
	public ArrayList<ReportQnaVO> allReportQna(ReportQnaVO qrvo) {
		return rqdao.allReportQna(qrvo);
	}

	@Override
	public ArrayList<ReportQnaVO> getEveryReportQna() {
		// TODO Auto-generated method stub
		return rqdao.getEveryReportQna();
	}

	@Override
	public ArrayList<RepContentVO> getRepConQna(int qnaId) {
		// TODO Auto-generated method stub
		return rqdao.getRepConQna(qnaId);
	}

}
