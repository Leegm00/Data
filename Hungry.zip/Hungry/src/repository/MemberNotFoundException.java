package repository;

public class MemberNotFoundException extends Exception {

}
