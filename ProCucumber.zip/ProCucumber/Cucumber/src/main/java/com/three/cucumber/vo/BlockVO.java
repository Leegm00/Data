package com.three.cucumber.vo;

public class BlockVO {
	private int blockId;
	private int blocker;
	private int blocked;
	private String blockedNick;
	
	
	public BlockVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BlockVO(int blockId, int blocker, int blocked, String blockedNick) {
		super();
		this.blockId = blockId;
		this.blocker = blocker;
		this.blocked = blocked;
		this.blockedNick = blockedNick;
	}
	
	public String getBlockedNick() {
		return blockedNick;
	}
	public void setBlockedNick(String blockedNick) {
		this.blockedNick = blockedNick;
	}
	public int getBlockId() {
		return blockId;
	}
	public void setBlockId(int blockId) {
		this.blockId = blockId;
	}
	public int getBlocker() {
		return blocker;
	}
	public void setBlocker(int blocker) {
		this.blocker = blocker;
	}
	public int getBlocked() {
		return blocked;
	}
	public void setBlocked(int blocked) {
		this.blocked = blocked;
	}
	
	
}
