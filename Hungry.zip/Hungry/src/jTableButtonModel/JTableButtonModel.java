package jTableButtonModel;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.DefaultCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import a.Index;
import repository.StoreDAO;

public class JTableButtonModel extends DefaultCellEditor {
	private String label;
	public JButton rec_btn;
	private StoreDAO storeDAO;
	Index index = new Index();
	private boolean isRec;
	ImageIcon like;

	public JTableButtonModel(StoreDAO storeDAO) {
		super(new JCheckBox());
		this.storeDAO = storeDAO;
		rec_btn = new JButton();
	}

	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
		String memid = index.getMemid();
		String storeName = (String) table.getValueAt(row, 0);
		int storeId = storeDAO.getStoreId(storeName);
		try {
			int recStoreId = storeDAO.recStore_rs(memid, storeId);
			if (recStoreId != -1 && recStoreId != storeId) {
				like = new ImageIcon(getClass().getResource("like.png"));
				label = "��õ!";
				isRec = false;
				value = false;
			} else {
				like = new ImageIcon(getClass().getResource("unlike.png"));
				label = "��õ ���";
				isRec = true;
				value = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		rec_btn.setIcon(like);

		ActionListener[] actionListeners = rec_btn.getActionListeners();
		for (ActionListener actionListener : actionListeners) {
			rec_btn.removeActionListener(actionListener);
		}

		rec_btn.addActionListener(new ActionListener() {
			private JTable tableModel;

			public void actionPerformed(ActionEvent e) {
				if (row != -1) {
					try {
						if (!isRec) {
//							   
							JOptionPane.showMessageDialog(null, "���Ը� ��õ�Ͽ����ϴ�.");
							ImageIcon unlike = new ImageIcon(getClass().getResource("unlike.png"));
							rec_btn.setIcon(unlike);
							storeDAO.updateCntPlus(storeId);
							storeDAO.recUpdate(storeId, memid);
							isRec = true;
						} else {
							JOptionPane.showMessageDialog(null, "��õ�� ����ϼ̽��ϴ�.");
							ImageIcon like = new ImageIcon(getClass().getResource("like.png"));
							rec_btn.setIcon(like);
							storeDAO.updateCntMinus(storeId);
							storeDAO.recDelete(storeId, memid);
							isRec = false;
						}
						 DefaultTableModel model = (DefaultTableModel) table.getModel();
						    int recommendColumnIndex = 3;
						    int selectedRowIndex = row;
						    int currentRecommendCount = (int) model.getValueAt(selectedRowIndex, recommendColumnIndex);
						    model.setValueAt(currentRecommendCount + (isRec ? +1 : -1), selectedRowIndex, recommendColumnIndex);
						    model.fireTableDataChanged();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
		});

		return rec_btn;
	}

	public boolean getRec() {
		return isRec;
	}

	public void setRec(boolean rec) {
		isRec = rec;
	}
}