package com.three.cucumber.service.dao;


import java.util.ArrayList;

import com.three.cucumber.vo.CateVO;
import com.three.cucumber.vo.GraphVO;
import com.three.cucumber.vo.PostVO;

public interface PostDAO {
	
	ArrayList<CateVO> getAllCate();
	
	void insertPost(PostVO postvo);
	
	String getMemNickPost(int memId);
	
	PostVO getPostVO(int postId);
	
	void updatePost(PostVO postvo);
	
	int deletePost(int postId);

	String findTitle(int postId);
	
	void upPostImgDel2(int postId);
	
	void upPostImgDel3(int postId);

	ArrayList<GraphVO> getAllGraph();

	void upGraph(GraphVO gvo);

	ArrayList<CateVO> getAllDelCate();

	void delCate(CateVO cvo);

	void inCate(CateVO cvo);

	void upCate(CateVO cvo);

	int checkCate(String cateName);

	void updatePipath2(PostVO postvo);
	
	void updatePipath3(PostVO postvo);
	
}
