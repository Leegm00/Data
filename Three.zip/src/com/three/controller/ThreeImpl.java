package com.three.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface ThreeImpl {
	public void three (HttpServletRequest request, HttpServletResponse response) throws Exception;
}
