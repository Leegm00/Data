package com.three.cucumber.vo;

import java.util.ArrayList;
import java.util.HashMap;

public class ReportPostVO {
	private int postReportId;
	private int postReportMem;
	private int postId;
	private int repId;
	private String postTitle;
	private ArrayList<RepContentVO> repConArray;
	
	public ReportPostVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReportPostVO(int postReportId, int postReportMem, int postId, int repId
							, String postTitle, ArrayList<RepContentVO> repConArray) {
		super();
		this.postReportId = postReportId;
		this.postReportMem = postReportMem;
		this.postId = postId;
		this.repId = repId;
		this.postTitle = postTitle;
		this.repConArray=repConArray;
	}

	public ArrayList<RepContentVO> getRepConArray() {
		return repConArray;
	}

	public void setRepConArray(ArrayList<RepContentVO> repConArray) {
		this.repConArray = repConArray;
	}

	public int getPostReportId() {
		return postReportId;
	}

	public void setPostReportId(int postReportId) {
		this.postReportId = postReportId;
	}

	public int getPostReportMem() {
		return postReportMem;
	}

	public void setPostReportMem(int postReportMem) {
		this.postReportMem = postReportMem;
	}

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	
	public int getRepId() {
		return repId;
	}

	public void setRepId(int repId) {
		this.repId = repId;
	}
	
	public String getPostTitle() {
		return postTitle;
	}

	public void setPostTitle(String postTitle) {
		this.postTitle = postTitle;
	}

	
}
