package com.three.cucumber.vo;

public class ChatReportVO {
    private  int chatReportId;
    private int chatReported;
    private int chatReporter;
    private String chatReportPipath;
    private int repId;
    private String repContent;
    
    
	public ChatReportVO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public ChatReportVO(int chatReportId, int chatReported, int chatReporter, String chatReportPipath,
			int repId, String repContent) {
		super();
		this.chatReportId = chatReportId;
		this.chatReported = chatReported;
		this.chatReporter = chatReporter;
		this.chatReportPipath = chatReportPipath;
		this.repId = repId;
		this.repContent=repContent;
	}


	public String getRepContent() {
		return repContent;
	}


	public void setRepContent(String repContent) {
		this.repContent = repContent;
	}


	public int getChatReportId() {
		return chatReportId;
	}


	public void setChatReportId(int chatReportId) {
		this.chatReportId = chatReportId;
	}


	public int getChatReported() {
		return chatReported;
	}


	public void setChatReported(int chatReported) {
		this.chatReported = chatReported;
	}


	public int getChatReporter() {
		return chatReporter;
	}


	public void setChatReporter(int chatReporter) {
		this.chatReporter = chatReporter;
	}


	public String getChatReportPipath() {
		return chatReportPipath;
	}


	public void setChatReportPipath(String chatReportPipath) {
		this.chatReportPipath = chatReportPipath;
	}


	public int getRepId() {
		return repId;
	}


	public void setRepId(int repId) {
		this.repId = repId;
	}

	

	
	
}