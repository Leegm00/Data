function delBuy(buyId){
	if(window.confirm('해당 구매 내역을 삭제하시겠습니까?')) {
		location.href="delBuyPost.do?buyId="+buyId;
	}
	else return false;
}
function notMine(id){
	if(window.confirm('구매한 적 없는 글인가요?')) {
		alert("해당 구매내역을 삭제합니다")
		location.href="notBuyPost.do?buyId="+id;
	}
}