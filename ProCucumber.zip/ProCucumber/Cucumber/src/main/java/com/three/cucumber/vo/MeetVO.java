package com.three.cucumber.vo;

public class MeetVO {
	private int meetId;
	private int chatId;
	private int meetFrom;
	private int meetTo;
	private String meetDate;
	private String meetTime;
	
	
	public MeetVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MeetVO(int meetId, int chatId, int meetFrom, int meetTo, String meetDate, String meetTime) {
		super();
		this.meetId = meetId;
		this.chatId = chatId;
		this.meetFrom = meetFrom;
		this.meetTo = meetTo;
		this.meetDate = meetDate;
		this.meetTime = meetTime;
	}
	
	public int getChatId() {
		return chatId;
	}
	public void setChatId(int chatId) {
		this.chatId = chatId;
	}
	public int getMeetId() {
		return meetId;
	}
	public void setMeetId(int meetId) {
		this.meetId = meetId;
	}
	public int getMeetFrom() {
		return meetFrom;
	}
	public void setMeetFrom(int meetFrom) {
		this.meetFrom = meetFrom;
	}
	public int getMeetTo() {
		return meetTo;
	}
	public void setMeetTo(int meetTo) {
		this.meetTo = meetTo;
	}
	public String getMeetDate() {
		return meetDate;
	}
	public void setMeetDate(String meetDate) {
		this.meetDate = meetDate;
	}
	public String getMeetTime() {
		return meetTime;
	}
	public void setMeetTime(String meetTime) {
		this.meetTime = meetTime;
	}
	
	
}
