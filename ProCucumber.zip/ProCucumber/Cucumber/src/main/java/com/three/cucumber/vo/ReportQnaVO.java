package com.three.cucumber.vo;

import java.util.ArrayList;

public class ReportQnaVO {
	private int qnaReportId;
	private int qnaReportMem;
	private int postId;
	private int qnaId;
	private int repId;
	private String qnaContent;
	private ArrayList<RepContentVO> repConArray;
	
	public ReportQnaVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReportQnaVO(int qnaReportId, int qnaReportMem, int postId, int qnaId, int repId
					, String qnaContent, ArrayList<RepContentVO> repConArray) {
		super();
		this.qnaReportId = qnaReportId;
		this.qnaReportMem = qnaReportMem;
		this.postId = postId;
		this.qnaId = qnaId;
		this.repId = repId;
		this.qnaContent = qnaContent;
		this.repConArray = repConArray;
	}

	public int getQnaReportId() {
		return qnaReportId;
	}

	public void setQnaReportId(int qnaReportId) {
		this.qnaReportId = qnaReportId;
	}

	public int getQnaReportMem() {
		return qnaReportMem;
	}

	public void setQnaReportMem(int qnaReportMem) {
		this.qnaReportMem = qnaReportMem;
	}

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	public int getQnaId() {
		return qnaId;
	}

	public void setQnaId(int qnaId) {
		this.qnaId = qnaId;
	}
	
	public int getRepId() {
		return repId;
	}

	public void setRepId(int repId) {
		this.repId = repId;
	}
	
	public String getQnaContent() {
		return qnaContent;
	}

	public void setQnaContent(String qnaContent) {
		this.qnaContent = qnaContent;
	}

	public ArrayList<RepContentVO> getRepConArray() {
		return repConArray;
	}

	public void setRepConArray(ArrayList<RepContentVO> repConArray) {
		this.repConArray = repConArray;
	}
	
}	
