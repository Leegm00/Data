package com.three.cucumber.service;

import java.util.ArrayList;

import com.three.cucumber.vo.AlarmVO;

public interface AlarmService {

	void insertAlQna(AlarmVO avo);

	int getChatAlCnt(AlarmVO avo);

	void delBuyAl(int buyId);

	void delChatAl(AlarmVO avo);

	int getMeetAlCnt(AlarmVO avo);

	void upMeetAl(AlarmVO avo);

	ArrayList<AlarmVO> getAllAl(int session);

	void delAllAl(int session);

	void delAl(Integer integer);

}
