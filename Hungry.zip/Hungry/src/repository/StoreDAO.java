package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import connect.Connect;

public class StoreDAO {

	// 모든 카테고리 메뉴 출력
	public List<StoreVO> getMenuAll() {
		ArrayList<StoreVO> storearray = new ArrayList<>();
		String sql = "SELECT * FROM STORE ORDER BY 1";
		try (Connection conn = JdbcTemplate.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery()) {
			System.out.println("출력 성공1");
			while (rs.next()) {
				StoreVO store = new StoreVO();
				store.setStore_id(rs.getInt(1));
				store.setStore_name(rs.getString(2));
				store.setAddress(rs.getString(3));
				store.setTel(rs.getString(4));
				store.setRec_count(rs.getInt(5));
				storearray.add(store);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return storearray;
	}

	// 한식 메뉴 출력
	public List<StoreVO> getMenu1() {
		ArrayList<StoreVO> storearray = new ArrayList<>();
		String sql = "SELECT * FROM STORE WHERE CAT_ID=1";
		try (Connection conn = JdbcTemplate.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery()) {
			System.out.println("출력 성공1");
			while (rs.next()) {
				StoreVO store = new StoreVO();
				store.setStore_id(rs.getInt(1));
				store.setStore_name(rs.getString(2));
				store.setAddress(rs.getString(3));
				store.setTel(rs.getString(4));
				store.setRec_count(rs.getInt(5));
				storearray.add(store);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return storearray;
	}

	// 중식 메뉴 출력
	public List<StoreVO> getMenu2() {
		ArrayList<StoreVO> storearray = new ArrayList<>();
		String sql = "SELECT * FROM STORE WHERE CAT_ID=2";
		try (Connection conn = JdbcTemplate.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery()) {
			System.out.println("출력 성공2");
			while (rs.next()) {
				StoreVO store = new StoreVO();
				store.setStore_id(rs.getInt(1));
				store.setStore_name(rs.getString(2));
				store.setAddress(rs.getString(3));
				store.setTel(rs.getString(4));
				store.setRec_count(rs.getInt(5));
				storearray.add(store);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("출력 실패");
		}
		return storearray;
	}

	// 일식 메뉴 출력
	public List<StoreVO> getMenu3() {
		ArrayList<StoreVO> storearray = new ArrayList<>();
		String sql = "SELECT * FROM STORE WHERE CAT_ID=3";
		try (Connection conn = JdbcTemplate.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery()) {
			System.out.println("출력 성공3");
			while (rs.next()) {
				StoreVO store = new StoreVO();
				store.setStore_id(rs.getInt(1));
				store.setStore_name(rs.getString(2));
				store.setAddress(rs.getString(3));
				store.setTel(rs.getString(4));
				store.setRec_count(rs.getInt(5));
				storearray.add(store);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("출력 실패");
		}
		return storearray;
	}

	// 양식 메뉴 출력
	public List<StoreVO> getMenu4() {
		ArrayList<StoreVO> storearray = new ArrayList<>();
		String sql = "SELECT * FROM STORE WHERE CAT_ID=4";
		try (Connection conn = JdbcTemplate.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery()) {
			System.out.println("출력 성공4");
			while (rs.next()) {
				StoreVO store = new StoreVO();
				store.setStore_id(rs.getInt(1));
				store.setStore_name(rs.getString(2));
				store.setAddress(rs.getString(3));
				store.setTel(rs.getString(4));
				store.setRec_count(rs.getInt(5));
				storearray.add(store);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("출력 실패");
		}
		return storearray;
	}

	// 삭제기능
	public void deleteStore(String storeName) throws SQLException {

		try {
			Connection conn = JdbcTemplate.getConnection();
			String sql = "DELETE FROM store WHERE store_name=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, storeName);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 가게이름 수정기능
	public void updateStore(String storeName, String newstoreName) {
		try {
			Connection conn = JdbcTemplate.getConnection();
			String sql = "update store " + "set store_name=? " + "where store_name=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, newstoreName);
			pstmt.setString(2, storeName);

			pstmt.executeUpdate();
			System.out.println("수정 완료");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 모든 가게아이디 추출
	public List<StoreVO> getStoreId() {
		ArrayList<StoreVO> storearray = new ArrayList<>();
		String sql = "select store_id from store";
		try (Connection conn = JdbcTemplate.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery()) {
			while (rs.next()) {
				StoreVO store = new StoreVO();
				store.setStore_id(rs.getInt(1));
				storearray.add(store);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return storearray;
	}

	// DB에 있는 store_id를 제외하고 무작위로 Id생성
	public int generateNewStoreId() {
		List<Integer> existingIds = new ArrayList<>();// 이미 있는 수를 리스트에 담기위해 생성
		for (StoreVO store : getStoreId()) { // DB에서 store_id를 가져온뒤 리스트에 추가함
			existingIds.add(store.getStore_id());
		}
		int newId;
		Random random = new Random();
		do {
			newId = random.nextInt(1000); // 0~999 중 무작위로 생성
		} while (existingIds.contains(newId)); // 이미 존재하는 ID인 경우 다시 생성
		return newId;
	}

	// 가게 추가하기
	public void insertStore(String storeName, String address, String tel, int cat_id) {
		int newId = generateNewStoreId(); // DB에 존재하지 않은 수
		int rec_cnt = new Random().nextInt(5) + 1; // 1~5 중 무작위로
		try {

			Connection conn = JdbcTemplate.getConnection();
			String sql = "INSERT INTO STORE (store_id, store_name, address, tel, rec_cnt, cat_id)"
					+ "VALUES (?, ?, ?, ?, ?, ?)";
			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, newId);
			pstmt.setString(2, storeName);
			pstmt.setString(3, address);
			pstmt.setString(4, tel);
			pstmt.setInt(5, rec_cnt);
			pstmt.setInt(6, cat_id);
			pstmt.executeUpdate();
			System.out.println("삽입 완료");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 추천 버튼 눌었을떄
	public void updateCntPlus(int store_id) {
		try {
			Connection conn = JdbcTemplate.getConnection();
			String sql = "update store set rec_cnt=rec_cnt+1 where store_id=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, store_id);

			pstmt.executeUpdate();
			System.out.println("수정 완료");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 추천 버튼 한번 더 눌었을떄 (추천 취소)
	public void updateCntMinus(int store_id) {
		try {
			Connection conn = JdbcTemplate.getConnection();
			String sql = "update store set rec_cnt=rec_cnt-1 where store_id=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, store_id);

			pstmt.executeUpdate();
			System.out.println("수정 완료");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	// rec_id추출

	public List<RecVO> getRecId() {
		ArrayList<RecVO> recrray = new ArrayList<>();
		String sql = "select rec_id from recommend";
		try (Connection conn = JdbcTemplate.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery()) {
			while (rs.next()) {
				RecVO rec = new RecVO();
				rec.setRec_id(rs.getInt(1));
				recrray.add(rec);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return recrray;
	}

	// DB에 있는 rec_id를 제외하고 무작위로 Id생성
	public int NewRecId() {
		List<Integer> existingIds = new ArrayList<>();// 이미 있는 수를 리스트에 담기위해 생성
		for (RecVO rec : getRecId()) { // DB에서 store_id를 가져온뒤 리스트에 추가함
			existingIds.add(rec.getRec_id());
		}
		int newId;
		Random random = new Random();
		do {
			newId = random.nextInt(1000); // 0~999 중 무작위로 생성
		} while (existingIds.contains(newId)); // 이미 존재하는 ID인 경우 다시 생성
		return newId;
	}

	// rec table 추천행 추가
	public void recUpdate(int store_id, String memid) throws SQLException {
		int newId = NewRecId(); // DB에 존재하지 않은 수
		try {
			Connection conn = JdbcTemplate.getConnection();
			String sql = "INSERT INTO RECOMMEND" + " VALUES (?, ?, ?)";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, newId);
			pstmt.setInt(2, store_id);
			pstmt.setString(3, memid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// rec table 추천행 삭제
	public void recDelete(int store_id, String memid) throws SQLException {
		try {
			Connection conn = JdbcTemplate.getConnection();
			String sql = "delete from RECOMMEND where store_id=? and mem_id=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, store_id);
			pstmt.setString(2, memid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// recommend 내역 검색
	public int recStore_rs(String mem_id, int store_id) throws SQLException {
		System.out.println("추천 내역 있는지 검색");
		int storeid = 0; // 변수 초기화
		StoreVO store = new StoreVO(); // 객체 생성
		try {
			Connection conn = JdbcTemplate.getConnection();
			String sql = "SELECT store_id FROM RECOMMEND WHERE mem_id = ? AND store_id = ?";
			System.out.println("쿼리 전달됨");
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mem_id);
			pstmt.setInt(2, store_id);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) { // rs 변수의 값을 가져온 후에 처리
				store.setStore_id(rs.getInt(1));
				storeid = store.getStore_id();
				System.out.println(storeid);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return storeid;
	}

	// 스토어 아이디 추출(한개)
	public int getStoreId(String storename) {
		int storeid = 0;
		try {
			Connection conn = JdbcTemplate.getConnection();
			System.out.println("아이디추출");
			String sql = "SELECT store_id FROM store WHERE store_name = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, storename);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				storeid = rs.getInt("store_id");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return storeid;
	}

	// 추천테이블 전체 가져오기
	public List<RecVO> getAllRecommendations() {
		List<RecVO> recommendations = new ArrayList<>();
		try {
			Connection conn = JdbcTemplate.getConnection();
			String sql = "SELECT * FROM RECOMMEND";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				RecVO rec = new RecVO();
				rec.setMem_id(3);
				rec.setStore_id(2);
				recommendations.add(rec);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return recommendations;
	}

	// 메뉴별 나이대
	public List<StoreVO> getMenuAge(int cat_id, String age) {
		ArrayList<StoreVO> storearray = new ArrayList<>();
		String sql = "select distinct s.*" + " from store s, member m, recommend r" + " where s.store_id = r.store_id"
				+ " and r.mem_id = m.mem_id" + " and s.cat_id = ?" + " and m.age = ?" + " order by s.rec_cnt desc";

		try {
			Connection conn = JdbcTemplate.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, cat_id);
			pstmt.setString(2, age);

			ResultSet rs = pstmt.executeQuery();
			{
				while (rs.next()) {
					StoreVO store = new StoreVO();
					store.setStore_id(rs.getInt(1));
					store.setStore_name(rs.getString(2));
					store.setAddress(rs.getString(3));
					store.setTel(rs.getString(4));
					store.setRec_count(rs.getInt(5));
					storearray.add(store);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("출력 실패");
		}
		return storearray;
	}

	// 메뉴 & 성별
	public List<StoreVO> getMenuGender(int cat_id, String gender) {
		ArrayList<StoreVO> storearray = new ArrayList<>();
		String sql = "select distinct s.*" + "from store s, member m, recommend " + "where s.store_id = r.store_id"
				+ "and m.mem_id = r.mem_id" + "and s.cat_id = ?" + "and m.gender = ?" + "order by s.rec_cnt desc";
		try {
			Connection conn = JdbcTemplate.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, cat_id);
			pstmt.setString(2, gender);

			ResultSet rs = pstmt.executeQuery();
			{
				while (rs.next()) {
					StoreVO store = new StoreVO();
					store.setStore_id(rs.getInt(1));
					store.setStore_name(rs.getString(2));
					store.setAddress(rs.getString(3));
					store.setTel(rs.getString(4));
					store.setRec_count(rs.getInt(5));
					storearray.add(store);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("출력 실패");
		}
		return storearray;
	}

	// 메뉴 & 나이 & 성별
	public List<StoreVO> getMenuAll(int cat_id, String age, String gender) {
		ArrayList<StoreVO> storearray = new ArrayList<>();
		String sql = "SELECT DISTINCT s.* FROM store s, member m, recommend r WHERE s.store_id = r.store_id"
				+ "  AND r.mem_id = m.mem_id  AND s.cat_id = ?  AND m.age = ?  AND gender = ?"
				+ "ORDER BY s.rec_cnt DESC";
		try {
			Connection conn = JdbcTemplate.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, cat_id);
			pstmt.setString(2, age);
			pstmt.setString(3, gender);

			ResultSet rs = pstmt.executeQuery();
			{
				while (rs.next()) {
					StoreVO store = new StoreVO();
					store.setStore_id(rs.getInt(1));
					store.setStore_name(rs.getString(2));
					store.setAddress(rs.getString(3));
					store.setTel(rs.getString(4));
					store.setRec_count(rs.getInt(5));
					storearray.add(store);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("출력 실패");
		}
		return storearray;
	}

}
