var revId;
function allRev(revRad) {
	var memId = document.getElementById('memId').value;
	location.href='allRev.do?revRad='+revRad+'&memId='+memId;
}
function report() {
	alert("신고되었습니다");
	document.getElementById("revId").value = revId;
	document.getElementById("reportForm").submit();
}

function delRev(revId) {
	if(window.confirm('해당 리뷰를 삭제하시겠습니까?'))
		location.href="delRev.do?revId="+revId;
	else return false;
}
function repRev(id) {
	revId = id;
}
function block(blocked) {
	var blocked = blocked;
	if(window.confirm("차단을 하면 해당 회원의 게시물과 \n댓글, 채팅이 보이지 않고 알림도 발송되지 않습니다")){
		location.href="revBlock.do?blocked="+blocked;
	}
		
}