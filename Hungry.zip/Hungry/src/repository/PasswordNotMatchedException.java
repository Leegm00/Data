package repository;

public class PasswordNotMatchedException extends Exception {

}
