package repository;

import java.util.Date;

public class StoreVO {
	int store_id;
	String store_name;
	String address;
	String tel;
	int rec_cnt;
	int cat_id;
	
	public StoreVO() {}
	public StoreVO(String store_name, String address, int rec_cnt) {
		this.store_name = store_name;
		this.address = address;
		this.rec_cnt = rec_cnt;
	}
	
	public int getStore_id() {
		return store_id;
	}	

	public void setStore_id(int store_id) {
		this.store_id = store_id;
	}

	public String getStore_name() {
		return store_name;
	}

	public void setStore_name(String store_name) {
		this.store_name = store_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public int getRec_cnt() {
		return rec_cnt;
	}

	public void setRec_count(int rec_cnt) {
		this.rec_cnt = rec_cnt;
	}

	public int getCat_id() {
		return cat_id;
	}

	public void setCat_id(int cat_id) {
		this.cat_id = cat_id;
	}
	@Override
	public String toString() {
		return "Store [store_id=" + store_id + ", store_name=" + store_name
				+ ", address=" + address + ", tel=" + tel
				+ ", rec_cnt=" + rec_cnt + ", cat_id="+cat_id+"]";
	}
	

	}
