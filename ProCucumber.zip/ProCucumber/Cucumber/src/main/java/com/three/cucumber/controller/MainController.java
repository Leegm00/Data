package com.three.cucumber.controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.three.cucumber.service.AlarmService;
import com.three.cucumber.service.BlockService;
import com.three.cucumber.service.HomeService;
import com.three.cucumber.service.LikeyService;
import com.three.cucumber.service.MemberService;
import com.three.cucumber.service.PostService;
import com.three.cucumber.service.QnaService;
import com.three.cucumber.service.RepContentService;
import com.three.cucumber.service.ReportPostService;
import com.three.cucumber.service.ReportQnaService;
import com.three.cucumber.vo.AlarmVO;
import com.three.cucumber.vo.BlockVO;
import com.three.cucumber.vo.CateVO;
import com.three.cucumber.vo.Criteria;
import com.three.cucumber.vo.GraphVO;
import com.three.cucumber.vo.LikeyVO;
import com.three.cucumber.vo.MemberVO;
import com.three.cucumber.vo.PostVO;
import com.three.cucumber.vo.QnaVO;
import com.three.cucumber.vo.RepContentVO;
import com.three.cucumber.vo.ReportPostVO;
import com.three.cucumber.vo.ReportQnaVO;

@Controller
public class MainController {

	@Resource(name = "homeService")
	private HomeService hSer;

	@Resource(name = "memberService")
	private MemberService mSer;

	@Resource(name = "qnaService")
	private QnaService qSer;
	
	@Resource(name = "likeyService")
	private LikeyService lSer;
	
	@Resource(name = "reportPostService")
	private ReportPostService rpSer;
	
	@Resource(name = "reportQnaService")
	private ReportQnaService rqSer;
	
	@Resource(name = "alarmService")
	private AlarmService aSer;
	
	@Resource(name="repContentService")
	private RepContentService rcSer;
	
	@Resource(name="blockService")
	private BlockService bSer;
	
	@Resource(name="PostService")
	private PostService pSer;

	// ����ȭ�� ���
	@RequestMapping(value = "main.do", method = RequestMethod.GET)
	public String homeMain(HttpServletRequest request,Model model, Criteria cri, String alarm) throws Exception {

		cri.setMemId(mSer.getSession(request));
		Criteria allparray = hSer.allSearch(cri);
		ArrayList<CateVO> carray = hSer.getAllCate();
		if(alarm == null) alarm = "no";

		model.addAttribute("alarm", alarm);
		model.addAttribute("carray", carray);
		model.addAttribute("cri", allparray);
		return "home/main";
	}

	// ��Ű �����ϰ� �ŷ��� �󼼳������� ���� ��Ű ���� ��ȸ�� +1 ����
	@RequestMapping("detail.do")
	public String detail(@CookieValue(value = "view") String cookie, ReportQnaVO rqvo,HttpServletRequest request, HttpServletResponse response,
			 Integer postId, Model model ) throws Exception {  
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}

		System.out.println(postId);
		if (!(cookie.contains(String.valueOf(postId)))) {
			cookie += postId + "/";
			hSer.viewCount(postId);
		}
		response.addCookie(new Cookie("view", cookie));

		int memId = mSer.getSession(request);
		PostVO detail = hSer.detail(postId);
		MemberVO findMem = mSer.findMem(detail.getMemId());
		ArrayList<QnaVO> qarray = qSer.findMainQna(postId, memId);
		HashMap<Integer, ArrayList<QnaVO>> qrmap = new HashMap<Integer, ArrayList<QnaVO>>();
		for (int i = 0; i < qarray.size(); i++) {
			int qnaId = qarray.get(i).getQnaId();
			ArrayList<QnaVO> qrarray = qSer.findReply(qnaId, memId);
			qrmap.put(qnaId, qrarray);
		}
		
		ArrayList<ReportPostVO> rpvo = rpSer.allReportPost(postId);
		ArrayList<ReportQnaVO> rqarray = rqSer.allReportQna(rqvo);
		ArrayList<RepContentVO> reparray = rcSer.allRepCont();
		
		LikeyVO lvo = new LikeyVO(postId, mSer.getSession(request));
		
		int likey = lSer.checkLike(lvo);

		model.addAttribute("pdetail", detail);
		model.addAttribute("findMem", findMem);
		model.addAttribute("qarray", qarray);
		model.addAttribute("qrmap", qrmap);
		model.addAttribute("rpvo", rpvo);
		model.addAttribute("rpvo", rqarray);
		model.addAttribute("likey", likey);
		model.addAttribute("reparray", reparray);

		return "home/detail";
	}

	@RequestMapping(value = "insertQna.do", method = RequestMethod.POST)
	public String insertQna(HttpServletRequest request, QnaVO qvo, Model model, Integer postMem) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		/*
		 * ������ ���� Ȯ�ο� if(qvo.getMemId() != 0)
		 * System.out.println("���̵�� "+qvo.getMemId()); if(qvo.getPostId() != 0)
		 * System.out.println("����Ʈ ��ȣ "+qvo.getPostId()); if(qvo.getDepth() == 0)
		 * System.out.println("����" + qvo.getDepth()); if(qvo.getQnaContent() != null)
		 * System.out.println("���Ǵ� " +qvo.getQnaContent());
		 */
		
		int memId = mSer.getSession(request);
		if(postMem != memId) {
			int cnt = bSer.blockCh(postMem, memId);
				if(cnt == 0 ) {
					AlarmVO avo = new AlarmVO(0, postMem, qvo.getPostId(), "["+pSer.findTitle(qvo.getPostId())+"] �Խñ� ���� ����� �޷Ƚ��ϴ�", "qna");
					aSer.insertAlQna(avo);
				}		
		}
		qSer.insertQna(qvo);
		

		return "redirect:detail.do?postId=" + qvo.getPostId(); // detail.do�� �ҷ��� �� postId�� �ʿ�
	}

	@RequestMapping(value = "insertQnaReply.do", method = RequestMethod.POST)
	public String insertReply(HttpServletRequest request, QnaVO qvo, Model model, Integer MainQnaMem) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		/*
		 * ������ ���� Ȯ�ο� if(qvo.getMemId() != 0)
		 * System.out.println("���̵�� "+qvo.getMemId()); if(qvo.getPostId() != 0)
		 * System.out.println("����Ʈ ��ȣ "+qvo.getPostId()); if(qvo.getDepth() == 0)
		 * System.out.println("����" + qvo.getDepth()); if(qvo.getBundleId() != 0)
		 * System.out.println("������̵� "+qvo.getBundleId()); if(qvo.getQnaContent() !=
		 * null) System.out.println("���Ǵ� " +qvo.getQnaContent());
		 */
		int memId = mSer.getSession(request);
		if(memId != MainQnaMem) {
			int cnt = bSer.blockCh(MainQnaMem, memId);
			if(cnt == 0) {
				AlarmVO avo = new AlarmVO(0, MainQnaMem, qvo.getPostId(), "["+pSer.findTitle(qvo.getPostId())+"] �Խñ� ���� �� ��ۿ� ����� �޷Ƚ��ϴ�", "qna");
				aSer.insertAlQna(avo);
			}
		}
		if(qvo.getMention() != null) {
			int mentionMemId = mSer.findMemId(qvo.getMention().replaceFirst("@", ""));
			if(mentionMemId != 0) {
				// �����ϸ� �˸�
				int cnt = bSer.blockCh(mentionMemId, memId);
				if(cnt == 0) {
					System.out.println(cnt);
					AlarmVO avo = new AlarmVO(0, mentionMemId, qvo.getPostId(), "["+mSer.findNick(qvo.getMemId())+"]���� ��ۿ��� ����Ͽ����ϴ�", "qna");
					aSer.insertAlQna(avo);
				}
			}
		}
		qSer.insertReply(qvo);

		return "redirect:detail.do?postId=" + qvo.getPostId();
	}
	
	// likey in del ajax
	@RequestMapping(value="likey.do")
	@ResponseBody
	public int likePost(HttpServletRequest request, Integer postId, Model model) {
		LikeyVO vo = new LikeyVO(postId, mSer.getSession(request));
		
		int result = lSer.doLike(vo);
		
		return result;
	} 
	
	@RequestMapping(value="detReport.do", method = RequestMethod.POST)
	public String reportPost(HttpServletRequest request, Model model, Integer postId, Integer qnaId, Integer repId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		if(qnaId == 0) {
			ReportPostVO pvo = new ReportPostVO(0,mSer.getSession(request),postId,repId,null,null);
			rpSer.reportInsertatPost(pvo);
			return "redirect:main.do";
		}
		else {
			ReportQnaVO qvo = new ReportQnaVO(0,mSer.getSession(request),postId,qnaId,repId,null,null);
			rqSer.reportInsertofQna(qvo);
			return "redirect:detail.do?postId="+postId;
		}
		
		
	}
	
	@RequestMapping(value="delQna.do")
	public String delQna(HttpServletRequest request, Model model, Integer qnaId, Integer postId, Integer depth) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		qSer.delQna(qnaId, depth);
		
		return "redirect:detail.do?postId=" + postId;
	}
	
	@RequestMapping(value="detBlock.do")
	public String detBlock(HttpServletRequest request, Integer blocked, Integer postId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		BlockVO bvo = new BlockVO(0,mSer.getSession(request),blocked, null);
		bSer.inBlock(bvo);
		return "redirect:detail.do?postId=" + postId;
	}
	
	@RequestMapping(value="alarm.do")
	public String alarm(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ArrayList<AlarmVO> aaray = aSer.getAllAl(mSer.getSession(request));
		model.addAttribute("aarray", aaray);
		return "/home/alarm";
	}
	
	@RequestMapping(value="delAllAl.do")
	public String delAllAl(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		aSer.delAllAl(mSer.getSession(request));
		return "redirect:alarm.do";
	}
	
	@RequestMapping(value="delAl.do")
	public void delAl(HttpServletRequest request, Model model, Integer[] alarmIdar) {
		for (int i=0; i<alarmIdar.length; i++) {
			aSer.delAl(alarmIdar[i]);
		}
	}
	
	@RequestMapping(value="graph.do")
	public String graph(Model model) {
		ArrayList<GraphVO> garray = pSer.getAllGraph();
		model.addAttribute("garray", garray);
		return "home/graph";
	}
}