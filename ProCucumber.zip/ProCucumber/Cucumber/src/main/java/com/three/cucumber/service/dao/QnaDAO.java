package com.three.cucumber.service.dao;

import java.util.ArrayList;

import com.three.cucumber.vo.QnaVO;

public interface QnaDAO {

	ArrayList<QnaVO> findMainQna(int postId, int memId);
	
	ArrayList<QnaVO> findReply(int qnaId, int memId);
	
	void insertQna(QnaVO qvo);
	
	void insertReply(QnaVO qvo);
	
	ArrayList<QnaVO> findMemId(int qnaId);
	
	ArrayList<QnaVO> allQna(int postId);

	void delMainQna(int qnaId);

	void delSubQna(int qnaId);
	
	String findContent(int qnaId);

	int getMem(int qnaId);

	void insertReplyMen(QnaVO qvo);
}
