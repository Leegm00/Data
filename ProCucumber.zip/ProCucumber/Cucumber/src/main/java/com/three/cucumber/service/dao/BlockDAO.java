package com.three.cucumber.service.dao;

import java.util.ArrayList;

import com.three.cucumber.vo.BlockVO;

public interface BlockDAO {

	int blockCh(BlockVO bvo);

	void inBlock(BlockVO bvo);

	ArrayList<BlockVO> getAllBlock(int memId);

	void delBlock(Integer blockId);

}
