package a;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import repository.IdPasswordException;
import repository.Member;
import service.Service;

public class Index extends JFrame {

	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtPw;
	private static String memid="";
    public static void setMemid(String memid) {
        Index.memid = memid;
    }


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
//		System.setProperty("file.encoding", "UTF-8");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Index frame = new Index();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Index() {
		setTitle("로그인");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 439, 406);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnRegister = new JButton("가입하기");
		btnRegister.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Register register = new Register(); // Register 클래스의 인스턴스 생성
				register.setVisible(true); // register 창을 보이도록 설정
			}
		});
		btnRegister.setBounds(135, 220, 106, 43);
		contentPane.add(btnRegister);

		JLabel lblId = new JLabel("아이디");
		lblId.setFont(new Font("굴림", Font.PLAIN, 20));
		lblId.setBounds(27, 98, 98, 30);
		contentPane.add(lblId);

		JLabel lblPw = new JLabel("비밀번호");
		lblPw.setFont(new Font("굴림", Font.PLAIN, 20));
		lblPw.setBounds(27, 162, 98, 30);
		contentPane.add(lblPw);

		txtId = new JTextField();
		txtId.setFont(new Font("굴림", Font.PLAIN, 15));
		txtId.setBounds(135, 98, 224, 30);
		contentPane.add(txtId);
		txtId.setColumns(10);

		txtPw = new JTextField();
		txtPw.setFont(new Font("굴림", Font.PLAIN, 15));
		txtPw.setColumns(10);
		txtPw.setBounds(135, 169, 224, 30);
		contentPane.add(txtPw);

		JButton btnLogin = new JButton("로그인");
		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Service svc = new Service();
				String id = txtId.getText();
				String pw = txtPw.getText();
				Member member = null;
				try {
					member = svc.login(id, pw);
					System.out.println("로그인 성공!");
					
					if (id.equals("admin") && pw.equals("admin1")) {
						System.out.println("관리자창 이동");
						Admin admin = new Admin(); // Register 클래스의 인스턴스 생성
						admin.setVisible(true);
						dispose();
					}else {
					Index.setMemid(id);
					System.out.println("메뉴메인창으로 이동");
					StoreMain main = new StoreMain();
					main.setVisible(true);
					setVisible(false);
					}

					// 로그인 성공 시 메인 창 표시
				} catch (repository.MemberNotFoundException e1) {
					System.out.println("로그인 실패");
					JOptionPane.showMessageDialog(null, "로그인에 실패하였습니다.\n아이디 또는 비밀번호를 확인해주세요");
				} catch (IdPasswordException e1) {
					System.out.println("로그인 실패");
					JOptionPane.showMessageDialog(null, "로그인에 실패하였습니다.\n아이디 또는 비밀번호를 확인해주세요");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnLogin.setBounds(253, 220, 106, 43);
		contentPane.add(btnLogin);

	}

	public String getMemid() {
		System.out.println("getMemid: "+memid);
		return memid;
	}
}
