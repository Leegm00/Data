package com.three.cucumber.service.dao;

import java.util.ArrayList;

import com.three.cucumber.vo.AlarmVO;

public interface AlarmDAO {

	void insertAlQna(AlarmVO avo);

	int getChatAlCnt(AlarmVO avo);

	void delBuyAl(int buyId);

	void delChatAl(AlarmVO avo);

	int getMeetAlCnt(AlarmVO avo);

	void upMeetAl(AlarmVO avo);

	ArrayList<AlarmVO> getAllAl(int memId);

	void delAllAl(int memId);

	void delAl(Integer alarmId);

}
