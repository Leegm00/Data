function emailname(email) {
	document.getElementById('emailinput').value  = email;
}

function regpassword (password) {
	  var reg = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,10}$/
	  document.getElementById('checkpw').style.color = 'red';
	  document.getElementById('checkpw').innerHTML = '비밀번호 미일치';
	  document.getElementById('passwordCheck').value = '';
	  if(true == reg.test(password))
		  document.getElementById('regpass').style.color = 'green';
	  else
		  document.getElementById('regpass').style.color = 'red';
	  return;
}
	
function passCheck(pch) {
	var password = document.getElementById('pw').value;
	if(password == pch){
		document.getElementById('checkpw').style.color = 'green';
		document.getElementById('checkpw').innerHTML = '비밀번호 일치';
	}
	else{
		document.getElementById('checkpw').style.color = 'red';
		document.getElementById('checkpw').innerHTML = '비밀번호 미일치';
	}
}

function formcheck(){
	if(document.getElementById('userEmail').value == '' || document.getElementById('emailinput').value == '') {
		alert("이메일을 입력해 주세요");
		return false;
	}
	else if(document.getElementById('emailnum').innerText == '인증 미완료' || Ecode == '') {
		alert('이메일 인증을 진행해 주세요');
		return false;
	}
	else if(document.getElementById('pw').value == '' || document.getElementById('regpass').style.color == 'red') {
		alert('비밀번호를 확인해주세요');
		return false;
	}
	else if(document.getElementById('passwordCheck').value == '' || document.getElementById('passwordCheck').value != document.getElementById('pw').value) {
		alert('비밀번호 재확인을 확인해주세요');
		return false;
	}
	else if(document.getElementById('nick').value == '') {
		alert('닉네임을 입력해주세요');
		return false;
	}
	else if(document.getElementById('checknick').innerText == '닉네임 중복 미확인') {
		alert('닉네임 중복을 진행해주세요');
		return false;
	}
	else if(document.getElementById('checknick').innerText == '닉네임 중복 사용불가') {
		alert('다른 닉네임을 입력해주세요');
		return false;
	}
	else if(document.getElementById('telF').value == '' || document.getElementById('telM').value == '' || document.getElementById('telL').value == ''){
		alert('전화번호를 입력해주세요');
		return false;
	}
	else if(document.getElementById('pnum').innerText == '인증 미완료' || Pcode=='') {
		alert('전화번호 인증을 진행해 주세요');
		return false;
	}
	else {
		alert("회원가입 완료");
		document.getElementById('join').submit();
	}
}

var Ecode="";
function emailnum(){
	const email = $('#userEmail').val() +'@'+ $('#emailinput').val(); // 이메일 주소값 얻어오기!
	if(email == '') {
		alert("이메일을 입력해주세요");
		return false;
	}
	const checkInput = $('#checkInput'); // 인증번호 입력하는곳 
		$.ajax({
			type : 'post',
			url : "mailcheck.do",
			data : {
				email : email
			},
			success : function (data) {
				if(data == 'no') {
					alert("이미 가입된 이메일입니다");
					return false;
				}
				else {
					checkInput.attr('disabled', false);
					alert('인증번호가 전송되었습니다.');
					Ecode = data;
				}
			}					
		}); // end ajax
}

function emailRan(val){
	if(Ecode == val){
		document.getElementById('emailnum').style.color = 'green';
		document.getElementById('emailnum').innerHTML = '인증완료';
		document.getElementById('checkInput').disabled = true;
		document.getElementById('userEmail').readOnly = true;
		document.getElementById('emailinput').readOnly = true;
		document.getElementById('emailBtn').disabled = true;
	}
	else{
		document.getElementById('emailnum').style.color = 'red';
		document.getElementById('emailnum').innerHTML = '인증 미완료';
	}
}

var Pcode="";
function pnum(){
	const phone = $('#telF').val() + $('#telM').val() + $('#telL').val();
	if(phone == '') {
		alert("전화번호를 입력해주세요");
		return false;
	}
	const pInput = $('#pInput'); // 인증번호 입력하는곳 
		$.ajax({
			type : 'post',
			url : "phonecheck.do",
			data : {
				phone : phone
			},
			success : function (data) {
				if(data == 'no') {
					alert("이미 가입된 전화번호입니다");
					return false;
				}
				else {
					pInput.attr('disabled', false);
					alert('인증번호가 전송되었습니다.');
					Pcode = data;
				}
			}					
		}); // end ajax
}

function pRan(val){
	if(Pcode == val){
		document.getElementById('pnum').style.color = 'green';
		document.getElementById('pnum').innerHTML = '인증완료';
		document.getElementById('pInput').disabled = true;
		document.getElementById('telF').readOnly = true;
		document.getElementById('telM').readOnly = true;
		document.getElementById('telL').readOnly = true;
		document.getElementById('phoneBtn').disabled = true;
	}
	else{
		document.getElementById('pnum').style.color = 'red';
		document.getElementById('pnum').innerHTML = '인증 미완료';
	}
}

function ncheck(){
	if(document.getElementById('nick').value == ''){
		alert('닉네임을 입력해 주세요');
		return false;
	}
	var nick = $('#nick').val();
		$.ajax({
			type : 'post',
			url : "nickcheck.do",
			data : {
				nick : nick
			},
			success : function (data) {
				if(data == 'no') {
					document.getElementById('checknick').style.color = 'red';
					document.getElementById('checknick').innerHTML = '닉네임 중복 사용불가';
				}
				else {
					document.getElementById('checknick').style.color = 'green';
					document.getElementById('checknick').innerHTML = '닉네임 사용가능';	
					document.getElementById('nick').readOnly = true;		
				}
				
			}					
		}); // end ajax
}

function newNick() {
	document.getElementById('checknick').style.color = 'red';
	document.getElementById('checknick').innerHTML = '닉네임 중복 미확인';	
	document.getElementById('nick').readOnly = false;
}
function newTel() {
	document.getElementById('pnum').style.color = 'red';
	document.getElementById('pnum').innerHTML = '인증 미완료';
	document.getElementById('pInput').value = '';
	document.getElementById('pInput').disabled = true;
	document.getElementById('telF').readOnly = false;
	document.getElementById('telM').readOnly = false;
	document.getElementById('telL').readOnly = false;
	document.getElementById('phoneBtn').disabled = false;
}
function newEmail() {
	document.getElementById('emailnum').style.color = 'red';
	document.getElementById('emailnum').innerHTML = '인증 미완료';
	document.getElementById('checkInput').value = '';
	document.getElementById('checkInput').disabled = true;
	document.getElementById('userEmail').readOnly = false;
	document.getElementById('emailinput').readOnly = false;
	document.getElementById('emailBtn').disabled = false;
}