package repository;
// 아이디가 중복일경우
public class MemberAlreadyException extends Exception {
	public MemberAlreadyException(String msg) {
		super(msg);
	}
}
