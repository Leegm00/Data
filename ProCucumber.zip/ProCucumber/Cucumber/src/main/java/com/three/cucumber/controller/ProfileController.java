package com.three.cucumber.controller;

import java.io.File;
import java.util.ArrayList;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.three.cucumber.service.AlarmService;
import com.three.cucumber.service.BlockService;
import com.three.cucumber.service.MemberService;
import com.three.cucumber.service.PostService;
import com.three.cucumber.service.ProfileService;
import com.three.cucumber.service.RepContentService;
import com.three.cucumber.vo.AlarmVO;
import com.three.cucumber.vo.BlockVO;
import com.three.cucumber.vo.BuyVO;
import com.three.cucumber.vo.MemberVO;
import com.three.cucumber.vo.PostVO;
import com.three.cucumber.vo.RepContentVO;
import com.three.cucumber.vo.RevReportVO;
import com.three.cucumber.vo.RevVO;

@Controller
public class ProfileController {
	
	@Resource(name="memberService")
	private MemberService memSer;
	
	@Resource(name="profileService")
	private ProfileService proSer;
	
	@Resource(name="PostService")
	private PostService postSer;
	
	@Resource(name="alarmService")
	private AlarmService aSer;
	
	@Resource(name="blockService")
	private BlockService bSer;
	
	@Resource(name="repContentService")
	private RepContentService rcSer;
	
	@RequestMapping(value = "rev.do", method = RequestMethod.GET)
	public String rev(HttpServletRequest request, Model model, Integer receiver, Integer buyId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		String nick = memSer.findNick(receiver);
		model.addAttribute("buyId", buyId);
		 model.addAttribute("receiver", receiver);
		 model.addAttribute("nick", nick);
		return "/profile/rev";
	}
	
	@RequestMapping(value = "inRev.do", method = RequestMethod.POST)
	public String inRev(HttpServletRequest request, Model model, RevVO rvo) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		rvo.setRevWriter(memSer.getSession(request));
		int cnt = bSer.blockCh(rvo.getRevReceiver(), rvo.getRevWriter());
		 if(cnt == 0) {
			 AlarmVO aavo = new AlarmVO(0, rvo.getRevReceiver(), rvo.getRevId(), "["+memSer.findNick(rvo.getRevWriter())+"] ���� �ŷ��ı⸦ ���½��ϴ�", "review");
			 aSer.insertAlQna(aavo);
		 }
		proSer.inRev(rvo);
		return "redirect:allRev.do";
	}
	
	@RequestMapping(value = "mypage.do", method = RequestMethod.GET)
	public String mypage(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		MemberVO mvo = memSer.findMem(memSer.getSession(request));
		model.addAttribute("mvo", mvo);
		return "/profile/mypage";
	}
	
	
	@RequestMapping(value = "youpage.do", method = RequestMethod.GET)
	public String youpage(HttpServletRequest request, Integer memId, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		MemberVO mvo = memSer.findMem(memId);
		model.addAttribute("mvo", mvo);
		return "/profile/youpage";
	}
	
	@RequestMapping(value="likeyPost.do", method = RequestMethod.GET)
	public String likeyPost(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ArrayList<PostVO> parray = proSer.getAllPostByLikey(memSer.getSession(request));
		
		model.addAttribute("parray", parray);
		return "/my/likeyPost";
	}
	
	@RequestMapping(value="buyPost.do", method = RequestMethod.GET)
	public String buyPost(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		ArrayList<BuyVO> parray = proSer.getAllPostByBuy(memSer.getSession(request));
		
		model.addAttribute("parray", parray);
		return "/my/buyPost";
	}
	
	@RequestMapping(value="delBuyPost.do", method = RequestMethod.GET)
	public String delBuyPost(HttpServletRequest request, Model model, Integer buyId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		BuyVO bvo = proSer.findBuy(buyId);
		String saveDir = request.getSession().getServletContext().getRealPath("/resources/buy_img");
		File dir = new File(saveDir);
		File[] files = dir.listFiles();
		String file = bvo.getPipath();
		for(File f:files) {
			if(f.getName().equals(file)) {
				f.delete();
			}
		}
		proSer.delBuyPost(buyId);
		return "redirect:buyPost.do";
	}
	
	@RequestMapping(value="notBuyPost.do", method = RequestMethod.GET)
	public String notBuyPost(HttpServletRequest request, Model model, Integer buyId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		BuyVO bvo = proSer.findBuy(buyId);
		String saveDir = request.getSession().getServletContext().getRealPath("/resources/buy_img");
		File dir = new File(saveDir);
		File[] files = dir.listFiles();
		String file = bvo.getPipath();
		for(File f:files) {
			if(f.getName().equals(file)) {
				f.delete();
			}
		}
		aSer.delBuyAl(buyId);
		proSer.delBuyPost(buyId);
		return "redirect:buyPost.do";
	}

	@RequestMapping(value="allRev.do", method = RequestMethod.GET)
	public String allRev(HttpServletRequest request, String revRad, Integer memId, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		// ���� ���ų� ���� �ı�(�ٸ� ȸ���� ��������)
		// ����̵� ���� ���̸� ����
		// ���� �ְ� sesId �� ���� ������ �ٸ� �����
		// ���������� �ٸ������ �������� ���� ���ð��� �����´�
		ArrayList<RepContentVO> reparray = rcSer.allRepCont();
		if(memId == null) memId = memSer.getSession(request);
		if(revRad == null) revRad = "receive"; // �⺻�� ���� �ı�
		ArrayList<RevVO> rarray = proSer.getAllRev(memId,revRad);
		model.addAttribute("memId", memId);
		model.addAttribute("revRad", revRad);
		model.addAttribute("rarray", rarray);
		model.addAttribute("reparray", reparray);
		// revArray�� �ѱ��
		return "/my/myRev";
	}
	
	@RequestMapping(value="delRev.do", method = RequestMethod.GET)
	public String delRev(HttpServletRequest request, Model model, Integer revId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		proSer.delRev(revId);
		return "redirect:allRev.do";
	}
	
	@RequestMapping(value="myPost.do", method = RequestMethod.GET)
	public String myPost(HttpServletRequest request, String postRad, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		// �Խù�
		// �Ǹ���(+�ŷ���), ����, �ŷ��Ϸ� �Խù���  ǥ��
		if(postRad == null) postRad = "�Ǹ���";
		int memId = memSer.getSession(request);
		ArrayList<PostVO> parray = proSer.getAllMyPost(postRad, memId);
		// postArray�� �ѱ��
		model.addAttribute("parray", parray);
		model.addAttribute("postRad", postRad);
		return "/my/myPost";
	}
	
	@RequestMapping(value="otherPost.do", method = RequestMethod.GET)
	public String otherPost(HttpServletRequest request, Integer memId, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		// �ٸ� ����� �Ǹ���, �ŷ��� �Խù�
		ArrayList<PostVO> parray = proSer.getAllOtherPost(memId);
		model.addAttribute("parray", parray);
		return "/my/otherPost";
	} 
	
	@RequestMapping(value="revBlock.do", method = RequestMethod.GET)
	public String revBlock(HttpServletRequest request, BlockVO bvo, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		
		bvo.setBlocker(memSer.getSession(request));
		bSer.inBlock(bvo);
		return "redirect:allRev.do";
	} 
	
	@RequestMapping(value="revReport.do", method = RequestMethod.POST)
	public String revReport(HttpServletRequest request, RevReportVO rvo, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}
		
		proSer.repRev(rvo);
		return "redirect:allRev.do";
	}
	
	@RequestMapping(value="block.do", method = RequestMethod.GET)
	public String block(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}

		ArrayList<BlockVO> barray = bSer.getAllBlock(memSer.getSession(request));
		model.addAttribute("barray", barray);
		return "/my/block";
	}
	
	@RequestMapping(value="delBlock.do", method = RequestMethod.GET)
	public String delBlock(HttpServletRequest request, Model model, Integer blockId) {
		HttpSession session = request.getSession(false);
		if(session == null || session.getAttribute("sesId")==null) {
			return "redirect:main.do?alarm=badmem";
		}

		bSer.delBlock(blockId);
		return "redirect:block.do";
	}
	
	@RequestMapping(value="memBlock.do", method = RequestMethod.POST)
	public void memBlock(HttpServletRequest request, BlockVO bvo) {
		bvo.setBlocker(memSer.getSession(request));
		bSer.inBlock(bvo);
	}

}
