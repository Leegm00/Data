function block(e) {
	if(window.confirm('해당 회원을 차단하시겠습니까?')){
	$.ajax({
			type : 'post',
			url : "memBlock.do",
			data : {
				blocked : e
			},
			success : function () {
				alert("차단이 완료되었습니다");
			}					
		}); // end ajax		
	}
	else return false;
		
}