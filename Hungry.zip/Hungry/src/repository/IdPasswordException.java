package repository;

public class IdPasswordException extends Exception {
}