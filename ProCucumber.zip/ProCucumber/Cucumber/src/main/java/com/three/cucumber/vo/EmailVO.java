package com.three.cucumber.vo;

public class EmailVO {
	private String userName;
	private String pw;
	
	
	public EmailVO() {
		this.userName = "hagom0413@gmail.com";
		this.pw = "bslxjbidcdtjzhyo";
	}
	public String getUserName() {
		return userName;
	}
	public String getPw() {
		return pw;
	}
	
	

}
