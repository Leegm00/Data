function handleOnChange(e) {
	// 선택된 데이터의 텍스트값 가져오기
	const text = e.options[e.selectedIndex].text;		  
	// 선택한 텍스트 출력
	document.getElementById('up').value = text;
}
function chCate(type) {
	var cateName = document.getElementById(type).value;
	if(cateName == '') {
		alert('내용을 입력해 주세요');
		return false;
	}
	else{
		$.ajax({
			type : 'post',
			url : "checkCate.do",
			data : {
				cateName : cateName
			},
			success : function (data) {
				if(data != 0) {
					alert('이미 존재하는 카테고리입니다');
					return false;
				}
				else
					document.getElementById(type+'Form').submit();
			}					
		}); // end ajax
	}
}
function delCheck() {
	var repId = document.getElementById('del').value;
	if(repId == 0){
		alert('삭제할 카테고리를 선택해 주세요');
		return false;
	}
	else {
		alert('삭제 완료되었습니다');
		document.getElementById('delForm').submit();
	}
}
