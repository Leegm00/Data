function delMem(e) {
	if(window.confirm('회원을 강제 탈퇴하시겠습니까?'))
		location.href="adDelMem.do?memId="+e;
	else return false;
}

function up(e) {
	if(window.confirm('회원의 경고횟수를 수정하시겠습니까?'))
		document.getElementById('up'+e).submit();
	else return false;
}
