package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import connect.Connect;

public class DAO {
	
	// 회원 가입
	public void memberInsert(Member member) throws MemberAlreadyException {
		String sql = "insert into member values (?,?,?,?,?,?)";
		try (Connection conn = JdbcTemplate.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, member.getMem_id());
			pstmt.setString(2, member.getPw());
			pstmt.setString(3, member.getGender());
			pstmt.setString(4, member.getEmail());
			pstmt.setString(5, member.getTel());
			pstmt.setString(6, member.getAge());

			int result = pstmt.executeUpdate();
			System.out.println(result + "행이 삽입되었습니다.");
		} catch (SQLException e) {
			System.out.println(e);
			throw new MemberAlreadyException("중복!");
		}
	}

	// 회원 정보 검색(ID로 검색) // 메인에서 로그인 시 아이디를 DB에서 찾아 아이디를 매칭 시킴
	public Member memberSelectOne(String id) {
		String sql = "select * from member where mem_id=?";
		ResultSet rs = null;
		Member member = null;
		try (Connection conn = JdbcTemplate.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				member = new Member();
				member.setMem_id(rs.getString(1));
				member.setPw(rs.getString(2));
				member.setGender(rs.getString(3));
				member.setEmail(rs.getString(4));
				member.setTel(rs.getString(5));
				member.setAge(rs.getString(6));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return member;
	}

	// 전체 회원 조회
	public List<Member> memberSelectAll() {
		ArrayList<Member> result = new ArrayList<>();
		String sql = "select * from member ";
		try (Connection conn = JdbcTemplate.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery()) {
			System.out.println("연결 성공");
			while (rs.next()) {
				Member member = new Member();
				member = new Member();
				member.setMem_id(rs.getString(1));
				member.setPw(rs.getString(2));
				member.setGender(rs.getString(3));
				member.setEmail(rs.getString(4));
				member.setTel(rs.getString(5));
				member.setAge(rs.getString(6));
				result.add(member);
			}
		} catch (SQLException e) {
			System.out.println("연결 실패");
			e.printStackTrace();
		}
		return result;
	}

	// 회원 삭제
	public void memberDelete(String memId) throws SQLException {
		String sql = "delete from member where mem_id=?";
		try (Connection conn = JdbcTemplate.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, memId);

			int result = pstmt.executeUpdate();
			System.out.println(result + "행이 삭제되었습니다.");
		}
	}

	// 멤버 아이디 수정기능
	public void updateMemId(String memid, String newmemid) throws MemberAlreadyException {
		try {
			Connection conn = JdbcTemplate.getConnection();
			String sql = "update member set mem_id=? where mem_id=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, newmemid);
			pstmt.setString(2, memid);

			pstmt.executeUpdate();
			System.out.println("수정 완료");
		} catch (SQLException e) {
			throw new MemberAlreadyException("오류");
		}
	}
	// 멤버 비밀번호 수정기능
	public void updateMemPW(String memid, String pw) {
		try {
			Connection conn = JdbcTemplate.getConnection();
			String sql = "update member " + "set pw=? " + "where mem_id=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, pw);
			pstmt.setString(2, memid);
			
			pstmt.executeUpdate();
			System.out.println("수정 완료");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	

	

}