package com.three.cucumber.service.dao;

import java.util.ArrayList;

import com.three.cucumber.vo.RepContentVO;

public interface ReportContentDAO {

	ArrayList<RepContentVO> getAllRepCon();

	int checkRepCon(String repContent);

	void inRepCon(RepContentVO rvo);

	void upRepCon(RepContentVO rvo);

	void delRepCon(RepContentVO rvo);

	int delCheck(Integer repId);

}
