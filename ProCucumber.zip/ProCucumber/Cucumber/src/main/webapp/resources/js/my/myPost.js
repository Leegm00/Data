function myPost(postRad) {
	location.href='myPost.do?postRad='+postRad;
}

