package com.three.cucumber.vo;

public class PhoneMesVO {
	private String to;

	public PhoneMesVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PhoneMesVO(String to) {
		super();
		this.to = to;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}
	
	
}
