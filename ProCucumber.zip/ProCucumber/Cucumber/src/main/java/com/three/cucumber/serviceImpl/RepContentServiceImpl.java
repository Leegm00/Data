package com.three.cucumber.serviceImpl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.three.cucumber.service.RepContentService;
import com.three.cucumber.service.dao.ReportContentDAO;
import com.three.cucumber.vo.RepContentVO;

@Service("repContentService")
public class RepContentServiceImpl implements RepContentService{
	@Autowired
	private ReportContentDAO repConDAO;

	@Override
	public ArrayList<RepContentVO> allRepCont() {
		// TODO Auto-generated method stub
		return repConDAO.getAllRepCon();
	}

	@Override
	public int checkRepCon(String repContent) {
		// TODO Auto-generated method stub
		return repConDAO.checkRepCon(repContent);
	}

	@Override
	public void inRepCon(RepContentVO rvo) {
		repConDAO.inRepCon(rvo);
		
	}

	@Override
	public void upRepCon(RepContentVO rvo) {
		repConDAO.upRepCon(rvo);
		
	}

	@Override
	public void delRepCon(RepContentVO rvo) {
		repConDAO.delRepCon(rvo);
		
	}

	@Override
	public int delCheck(Integer repId) {
		// TODO Auto-generated method stub
		return repConDAO.delCheck(repId);
	}
}
