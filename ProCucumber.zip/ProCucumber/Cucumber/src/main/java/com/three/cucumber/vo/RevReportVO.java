package com.three.cucumber.vo;

public class RevReportVO {
	private int revRepId;
	private int revId;
	private int repId;
	private String revContent;
	private int reporter;
	private int reported;
	private String repContent;
	
	

	public RevReportVO(int revRepId, int revId, int repId, String revContent, int reporter, int reported,
			String repContent) {
		super();
		this.revRepId = revRepId;
		this.revId = revId;
		this.repId = repId;
		this.revContent = revContent;
		this.reporter = reporter;
		this.reported = reported;
		this.repContent = repContent;
	}
	public String getRevContent() {
		return revContent;
	}
	public void setRevContent(String revContent) {
		this.revContent = revContent;
	}
	public int getReporter() {
		return reporter;
	}
	public void setReporter(int reporter) {
		this.reporter = reporter;
	}
	public int getReported() {
		return reported;
	}
	public void setReported(int reported) {
		this.reported = reported;
	}
	public String getRepContent() {
		return repContent;
	}
	public void setRepContent(String repContent) {
		this.repContent = repContent;
	}
	public RevReportVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getRevRepId() {
		return revRepId;
	}
	public void setRevRepId(int revRepId) {
		this.revRepId = revRepId;
	}
	public int getRevId() {
		return revId;
	}
	public void setRevId(int revId) {
		this.revId = revId;
	}
	public int getRepId() {
		return repId;
	}
	public void setRepId(int repId) {
		this.repId = repId;
	}
	
	

}
