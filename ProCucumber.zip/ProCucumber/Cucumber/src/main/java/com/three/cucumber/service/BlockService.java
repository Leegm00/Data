package com.three.cucumber.service;

import java.util.ArrayList;

import com.three.cucumber.vo.BlockVO;

public interface BlockService {

	void inBlock(BlockVO bvo);

	int blockCh(int blocker, int blocked);

	ArrayList<BlockVO> getAllBlock(int session);

	void delBlock(Integer blockId);

}
