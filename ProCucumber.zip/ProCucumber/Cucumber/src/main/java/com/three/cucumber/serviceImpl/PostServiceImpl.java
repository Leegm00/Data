package com.three.cucumber.serviceImpl;



import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.three.cucumber.service.PostService;
import com.three.cucumber.service.dao.PostDAO;
import com.three.cucumber.vo.CateVO;
import com.three.cucumber.vo.GraphVO;
import com.three.cucumber.vo.PostVO;

@Service("PostService")
public class PostServiceImpl implements PostService {
	
	@Autowired
	private PostDAO pdao;
	
	
	@Transactional
	public ArrayList<CateVO> getAllCate(){
		return pdao.getAllCate();
	}
	
	@Override
	public void insertPost(PostVO postvo) throws SQLException{
		
		pdao.insertPost(postvo);
	}
	
	@Override
	public String getMemNickPost(int memId) {
		return pdao.getMemNickPost(memId);
	}
	
	@Override
	public PostVO getPostVO(int postId) {
		return pdao.getPostVO(postId);
	}
	
	@Override
	public void updatePost(PostVO postvo) throws SQLException{
		pdao.updatePost(postvo);
		if(postvo.getPipath2()!=null)
			pdao.updatePipath2(postvo);
		if(postvo.getPipath3()!=null)
			pdao.updatePipath3(postvo);
	};
	
	@Override
	public int deletePost(int postId) {
		return pdao.deletePost(postId);
	}
	
	@Override
	public String findTitle(int postId) {
		// TODO Auto-generated method stub
		return pdao.findTitle(postId);
	}

	@Override
	public void upPostImgDel2(int postId) {
		// TODO Auto-generated method stub
		pdao.upPostImgDel2(postId);
	}

	@Override
	public void upPostImgDel3(int postId) {
		// TODO Auto-generated method stub
		pdao.upPostImgDel3(postId);
	}

	@Override
	public ArrayList<GraphVO> getAllGraph() {
		// TODO Auto-generated method stub
		return pdao.getAllGraph();
	}

	@Override
	public void upGraph(GraphVO gvo) {
		// TODO Auto-generated method stub
		pdao.upGraph(gvo);
	}

	@Override
	public ArrayList<CateVO> getAllDelCate() {
		// TODO Auto-generated method stub
		return pdao.getAllDelCate();
	}

	@Override
	public void delCate(CateVO cvo) {
		// TODO Auto-generated method stub
		pdao.delCate(cvo);
	}

	@Override
	public void upCate(CateVO cvo) {
		// TODO Auto-generated method stub
		pdao.upCate(cvo);
	}

	@Override
	public void inCate(CateVO cvo) {
		pdao.inCate(cvo);
		
	}

	@Override
	public int checkCate(String cateName) {
		// TODO Auto-generated method stub
		return pdao.checkCate(cateName);
	}
}




