package a;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import repository.DAO;
import repository.Member;
import repository.MemberAlreadyException;
import repository.PasswordNotMatchedException;
import service.Service;

public class AdminMember extends JFrame implements ActionListener {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
//		System.setProperty("file.encoding", "UTF-8");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminMember frame = new AdminMember();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		});
	}

	private JTable table;
	private DefaultTableModel model;
	private JButton deleteButton;
	private JButton updateIdButton;
	private JButton updatePwButton;
	private JButton insertButton;

	/**
	 * Create the frame.
	 */
	public AdminMember() {

		setTitle("회원 관리");
		setSize(800, 400);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);

		DAO memberDAO = new DAO();

		table = new JTable();
		table.setRowHeight(30); // 행의 높이를 30으로 설정
		model = new DefaultTableModel(new Object[][] {}, new String[] { "회원 아이디", "비밀번호", "성별", "이메일","전화번호","연령" }) {
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isCellEditable(int row, int column) {
				return column >= 3;
			}
		};
		// 각 컬럼의 넓이 설정
		table.setModel(model);

		// JScrollPane으로 JTable 감싸기
		JScrollPane scrollPane = new JScrollPane(table);
		getContentPane().add(scrollPane, BorderLayout.CENTER);
		JPanel panel = new JPanel();

		// insert버튼
		insertButton = new JButton("추가");
		insertButton.addActionListener(this);
		panel.add(insertButton);
		getContentPane().add(panel, BorderLayout.SOUTH);
		// delete 버튼
		deleteButton = new JButton("삭제");
		deleteButton.addActionListener(this);
		panel.add(deleteButton);
		getContentPane().add(panel, BorderLayout.SOUTH);
		// 아이디 변경 버튼
		updateIdButton = new JButton("아이디 변경");
		updateIdButton.addActionListener(this);
		panel.add(updateIdButton);
		getContentPane().add(panel, BorderLayout.SOUTH);
		// 비밀번호 변경 버튼
		updatePwButton = new JButton("비밀번호 변경");
		updatePwButton.addActionListener(this);
		panel.add(updatePwButton);
		getContentPane().add(panel, BorderLayout.SOUTH);

		// 가로 사이즈 설정
		table.getColumnModel().getColumn(0).setPreferredWidth(200);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(2).setPreferredWidth(50);
		table.getColumnModel().getColumn(3).setPreferredWidth(50);

		// 전체 회원조회
		DAO dao = new DAO();
		List<Member> memberList = null;
		try {
			memberList = dao.memberSelectAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Member member : memberList) {
			Object[] row = { member.getMem_id(), member.getPw(), member.getGender(), member.getEmail(),member.getTel(),member.getAge() };
			model.addRow(row);
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Service service = new Service();
		DAO dao = new DAO();
		// 추가 버튼을 눌렀을때 이벤트
		if (e.getSource() == insertButton) {
			String[] options = { "10대", "20대", "30대", "40대", "50대 이상" };
			String[] opgen = { "남자", "여자" };
			String memid = JOptionPane.showInputDialog(this, "새로운 회원 아이디를 입력하세요.");
			String mempw = JOptionPane.showInputDialog(this, "비밀번호를 입력하세요.");
			String genders = null;
			String ages = null;
			String email = JOptionPane.showInputDialog(this, "이메일을 입력하세요.");
			String tel = JOptionPane.showInputDialog(this, "전화번호를 입력하세요.");
			int age = (JOptionPane.showOptionDialog(null, "나이대를 선택해주세요", "나이 선택", JOptionPane.DEFAULT_OPTION,
					JOptionPane.PLAIN_MESSAGE, null, options, options[0])) + 1;
			int gender = (JOptionPane.showOptionDialog(null, "성별을 선택해주세요", "성별 선택", JOptionPane.DEFAULT_OPTION,
					JOptionPane.PLAIN_MESSAGE, null, opgen, opgen[0])) + 1;
			if (gender == 1)
				genders = "M";
			else if (gender == 2)
				genders = "F";
			if(age==1) 
				ages="10대";
			else if(age==2)
				ages="20대";
			else if(age==3)
				ages="30대";
			else if(age==4)
				ages="40대";
			else if(age==5)
				ages="50대 이상";
			
			while (memid == null || mempw == null || age <= 0 || gender <= 0) {
				JOptionPane.showMessageDialog(null, "모든 항목을 입력해주세요.");
				memid = JOptionPane.showInputDialog(this, "새로운 회원 아이디를 입력하세요.");
				if (memid == null) {
					JOptionPane.showMessageDialog(null, "사용자가 취소하였습니다.");
					break;
				} // 입력 창이 닫힐 경우 바로 반복문을 빠져나옴
				mempw = JOptionPane.showInputDialog(this, "비밀번호를 입력하세요");
				if (mempw == null) {
					JOptionPane.showMessageDialog(null, "사용자가 취소하였습니다.");
					break;
				}
				email = JOptionPane.showInputDialog(this, "이메일을 입력하세요");
				if (email == null) {
					JOptionPane.showMessageDialog(null, "사용자가 취소하였습니다.");
					break;
				}
				tel = JOptionPane.showInputDialog(this, "전화번호를 입력하세요");
				if (tel == null) {
					JOptionPane.showMessageDialog(null, "사용자가 취소하였습니다.");
					break;
				}
				gender = (JOptionPane.showOptionDialog(null, "성별을 선택해주세요", "성별 선택", JOptionPane.DEFAULT_OPTION,
						JOptionPane.PLAIN_MESSAGE, null, opgen, opgen[0])) + 1;
				if (age <= 0) {
					JOptionPane.showMessageDialog(null, "사용자가 취소하였습니다.");
					break;
				}
				age = (JOptionPane.showOptionDialog(null, "나이대를 선택해주세요", "나이 선택", JOptionPane.DEFAULT_OPTION,
						JOptionPane.PLAIN_MESSAGE, null, options, options[0])) + 1;
				if (gender <= 0) {
					JOptionPane.showMessageDialog(null, "카테고리를 선택해주세요.");
				}
			}
			// 입력받은 값이 null이 아니면, 즉 사용자가 값을 입력한 경우 종속문장 실행
			if (memid != null && mempw != null && email != null 
					&& tel != null&& age >= 0 && gender >= 0) {

				try {
					System.out.println("service 전");
					service.register(memid, mempw, mempw,genders, email,tel,ages);
					System.out.println("service 후");
					JOptionPane.showMessageDialog(null, "회원등록이 완료되었습니다.");
					model.setRowCount(0);

					List<Member> memberList = dao.memberSelectAll();
					for (Member member : memberList) {
						Object[] row = { member.getMem_id(), member.getPw(), member.getGender(), member.getEmail(),member.getTel(),member.getAge() };
						model.addRow(row);
					}
				} catch (MemberAlreadyException e1) {
					JOptionPane.showMessageDialog(null, "이미 등록된 아이디입니다. 다른 아이디를 입력해주세요.");
					e1.printStackTrace();
				} catch (PasswordNotMatchedException e1) {
					JOptionPane.showMessageDialog(null, "회원가입에 실패했습니다. 다시 시도해주세요.");
					e1.printStackTrace();
					
				}
			}
		} else if (e.getSource() == deleteButton) {
			int selectedRow = table.getSelectedRow(); // 행 선택
			if (selectedRow != -1) { // 선택이 되었다면 종속문장 실행
				String memId = (String) model.getValueAt(selectedRow, 0); // 멤버아이디를 가져옴
				System.out.println(memId);
				int confirm = JOptionPane.showConfirmDialog(this, "정말로 삭제하시겠습니까?", "확인", JOptionPane.YES_NO_OPTION);
				if (confirm == JOptionPane.YES_OPTION) { // yes를 클릭한경우 종속문장 실행
					try {
						dao.memberDelete(memId);
					} catch (SQLException e1) {
						JOptionPane.showMessageDialog(null, "DB에서 삭제에 실패하였습니다.");
						e1.printStackTrace();
					}
					model.removeRow(selectedRow);
					JOptionPane.showMessageDialog(null, "삭제되었습니다.");
				}
			}
		} else if (e.getSource() == updateIdButton) { //id 변경
			int selectedRow = table.getSelectedRow(); // 행 선택
			if (selectedRow != -1) {
				String id = (String) model.getValueAt(selectedRow, 0);

				// 사용자가 수정할 값을 입력받음
				String newId = JOptionPane.showInputDialog(this, "변경하실 아이디를 입력하세요.");
				// 입력받은 값이 null이 아니면, 즉 사용자가 값을 입력한 경우 종속문장 실행
				if (newId != null) {
					// 수정 쿼리 실행
					try {
						System.out.println("oldId"+id);
						System.out.println("newId"+newId);
						dao.updateMemId(id, newId);
					} catch (MemberAlreadyException e1) {
						JOptionPane.showMessageDialog(null, "이미 DB에 아이디가 존재합니다.");
						e1.printStackTrace();
					}
					model.setValueAt(newId, selectedRow, 0);
					JOptionPane.showMessageDialog(null, "수정되었습니다.");
				}
			}
		} else if (e.getSource() == updatePwButton) {
			int selectedRow = table.getSelectedRow(); // 행 선택
			if (selectedRow != -1) {
				String id = (String) model.getValueAt(selectedRow, 0);

				// 사용자가 수정할 값을 입력받음
				String newpw = JOptionPane.showInputDialog(this, "변경하실 비밀번호를 입력하세요.");

				// 입력받은 값이 null이 아니면, 즉 사용자가 값을 입력한 경우 종속문장 실행
				if (newpw != null) {
					dao.updateMemPW(id, newpw);
					model.setValueAt(newpw, selectedRow, 1);
					JOptionPane.showMessageDialog(null, "수정되었습니다.");
				}
			}
		}
	}
}