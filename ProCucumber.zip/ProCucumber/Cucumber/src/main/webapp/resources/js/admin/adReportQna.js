function delQna(e) {
	if(window.confirm('문의글을 삭제하시겠습니까?'))
		location.href="adDelQna.do?qnaId="+e;
	else return false;
}

function delRepQna(e){
	if(window.confirm('신고를 삭제하시겠습니까?'))
		location.href="adDelRepQna.do?qnaId="+e;
	else return false;
}

function yellow(e){
	if(window.confirm('댓글 작성자를 경고하시겠습니까?')) {
			$.ajax({
			type : 'post',
			url : "yellowQna.do",
			data : {
				qnaId : e
			},
			success : function (data) {
				alert("댓글 작성자에게 경고가 완료되었습니다");
			}					
		}); // end ajax
	}
	else return false;
}